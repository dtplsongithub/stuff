const express = require("express")
const app = express();
const DBClient = require("@replit/database");
const dbclient = new DBClient();
const fs = require('fs');
const { Client, GatewayIntentBits, ActivityType, EmbedBuilder, ModerateMembers } = require('discord.js'); //the require stack™
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ],
});

// commands (yes, all of these are commands)

client.on('messageCreate', async (message) => {
  var update = true
  if (message.author.id == "1170104859865927791") return
  function giveAch(name, desc, message) {
    dbclient.get(message.author.id).then(dbdata => {
      let embed = new EmbedBuilder()
      embed.setTitle(name)
      embed.setDescription(desc)
      embed.setAuthor({ name: "new achievement unlocked " })
      embed.setFooter({ text: `unlocked by ${message.author.username}` })
      embed.setColor(0x0000ff)
      if (dbdata == null || dbdata.toString() == "") {
        dbclient.set(message.author.id, name)
        message.reply({ embeds: [embed] })
        return
      }
      const data = dbdata.toString().split(',')
      if (!data.includes(name)) {
        dbclient.set(message.author.id, `${dbdata},${name}`)
        message.reply({ embeds: [embed] })
      }
    })
  }
  let content = message.content.toLowerCase()
  
  try {
    if (message.content.startsWith("d??")) {
      var comma = message.content.substring(3);
      if (help[`${comma}`]) {
        message.channel.send(help[`${comma}`])
      } else if (commandshelp.includes(comma)) {
        message.channel.send(commandshelp[commandshelp.indexOf(comma) + 1])
      } else {
        message.channel.send("unknown command")
      }



    } else if (message.content.startsWith("d?")) {

      if (bannedId.includes(message.author.id)) {
        message.reply(`you have been banned from dcubed\nreason: ${banReason[`${message.author.id}`]}`)
        return
      }
      var comma = message.content.substring(2);
      if (comma == "test") {
        message.reply("IT WORKS");
        message.channel.send("it works");
      } else if (comma == "help") {
        let sends = "## dtpls_'s first discord bot (aka dcubed) help ##\n";
        for (let i = 0; i < commandshelp.length; i += 2) {
          sends += `**${commandshelp[i]}**: ${commandshelp[i + 1]}\n`
        }
        sends += "\n(prefix is d?)\nother commands:\nd??`command name`: d?help but only for that specific command"
        message.channel.send(sends)
        /*
        let exampleEmbed = new EmbedBuilder()
          .setColor(0x63f)
          .setTitle("dtpls_'s first discord bot (aka dcubed) help")
          .setAuthor({ name: 'dcubed' })
        .addFields({name: '\u200B', value: '\u200B' })
        for (let i=0;i<commandshelp.length;i+=2){
           exampleEmbed.addFields({ name:`${commandshelp[i]}` , value: `${commandshelp[i+1]}`})
        }
        message.channel.send({embeds: [exampleEmbed]})*/
      } else if (comma.startsWith("say") && (!saybannedId.includes(message.author.id))) {
        const text = comma.substring(4);
        if (text == "") {
          message.reply("no or else i will crash");
          return
        };
        message.reply(text);
      } else if (comma == "" || comma == "d?") {
        update = false;
        message.react("🤔"); // also used for testing
      } else if (comma == "ping") {
        message.reply(`i have brain delay of ${client.ws.ping}ms.`)
      } else if (comma.startsWith("yesorno")) {
        let aaaa = Math.round(Math.random() * (yesnod.length - 1))
        if (Math.random() < 0.005) {
          message.reply("```/home/runner/dcubed/index.js:101\n      message.reply(yesnod[aaaa]);\n                    ^\n\nTypeError: yesnod is not defined```")
          giveAch("secret message", "how", message)
        } else {
          message.reply(yesnod[aaaa]);
        }
      } else if (comma == "tictactoe") {
        if (!xogameopen && !xogamestarted) {
          thonpl = 0
          pplplaying = []
          ttt = [0, 0, 0, 0, 0, 0, 0, 0, 0]
          message.reply("ok, but wait")
          message.channel.send(showgame());
          xogameopen = true;
        } else {
          message.reply("a game of tic tac toe is already playing.")
        }
      } else if (comma.startsWith("place")) {
        update = false;
        if (!xogamestarted) {
          message.reply("not yet")
          return
        }
        if (pplplaying.includes(message.author.username)) {
          if (pplplaying.indexOf(message.author.username) == thonpl) {
            thonpl = Math.abs(thonpl - 1)
            const text = comma.substring(6);
            if (ttt[text + 1] == 0) {
              ttt[text + 1] = thonpl + 1
              message.channel.send(showgame() + "" + checkforwinxo());
            } else {
              message.reply("no, try again");
              return
            };
          } else {
            message.reply("bro its not your turn yet");

          }
        } else {
          message.reply("stfu man you aint playin'");
        }
      } else if (comma == "joinxog") {
        update = false;
        if (pplplaying.length == 2) {
          message.channel.send("shut the hell up");
          return;
        };
        if (pplplaying.includes(message.author.username)) {
          message.channel.send("you cant join twice thats silly");
          return;
        }
        pplplaying.push(message.author.username);
        message.channel.send(`ok, ${message.author.username} is p${pplplaying.length}`);
        if (pplplaying.length == 2) {
          xogameopen = false;
          xogamestarted = true;
          message.channel.send("ok, lets go!");
          console.log(pplplaying);
        };
      } else if (comma == "err") { throw ("err") } else if (comma.startsWith("mess")) {
        let messup = comma.substring(5);
        messup = messup.split('');
        function move(input, from, to) {
          let numberOfDeletedElm = 1;
          const elm = input.splice(from, numberOfDeletedElm)[0];
          numberOfDeletedElm = 0;
          input.splice(to, numberOfDeletedElm, elm);
        };
        function mari(a, b) {
          if (a > b) {
            var c = a;
            a = b;
            b = c;
          }
          return Math.floor(Math.random() * (b - a + 1) + a);
        }
        for (let i = 0; i < messup.length; i++) {
          move(messup, mari(i, messup.length));
        }
        message.reply('here:\n' + messup.join(''))
      } else if (comma == "achtest") {
        giveAch("test", "test", message);
      } else if (comma == "clear" && message.author.id == devId) {
        //  dbclient.clear();
        message.reply("this command is currently disabled. :duck:")
      } else if (comma == "achs") {
        dbclient.get(message.author.id).then(dbdata => {
          let achs = []

          if (dbdata == null) {
            message.channel.send("you do not have any achievements");
            return
          } else {
            achs = dbdata.split(",")
          }
          let send = "achievements: \n"
          for (let i = 0; i < achs.length; i++) {
            if (!achsdesc[achs[i]]) {
              send += `**${achs[i]}**:  unknown achievement\n`;
            } else {
              send += `**${achs[i]}**:  ` + achsdesc[achs[i]] + '\n';
            }
          }
          message.reply(send);
        })
      } else if (comma == "devtest") {
        if (message.author.id == devId) {
          message.reply("you are dev");
        } else if (helpedId.includes(message.author.id)) {
          message.reply("you arent dev but you did help with the bot")
        } else {
          message.reply("you aren't dev");
        }
      } else if (comma == "ver") {
        message.channel.send(`dcubed version ${dbot.ver.ver}\nbuild ${dbot.ver.build}\nfull version ${dbot.ver.fullver}`)
      } else if (comma == "whatsnew") {
        let send = `dcubed version ${dbot.ver.ver} changelog\n`
        for (i in chlog) {
          send += `**${chlog[i].ver}:**\n${chlog[i].change}\n\n`
        }
        message.channel.send(send)
      } else if (comma == "credits") {
        message.channel.send("made by dtpls_, maybe_cube\nideas by ilovelamapadaire")
      } else if (comma.startsWith("gibberish")) {
        let send = "";
        let start = false
        let start2 = false
        let listcomma = comma.substring(10).split(' ');
        for (let i = 0; i < 25; i++) {
          start = random(0, 1) == 1 ? true : false
          for (let j = 0; j < random(2, 7); j++) {
            start2 = random(0, 2) == 1 ? true : false
            if (start) {
              send += vocal[random(0, vocal.length - 1)];
              send += conso[random(0, conso.length - 1)];
              if (start2) {
                send += conso[random(0, conso.length - 1)];
              }
            } else {
              send += conso[random(0, conso.length - 1)];
              send += vocal[random(0, vocal.length - 1)];
              if (start2) {
                send += vocal[random(0, vocal.length - 1)];
              }
            }
          }
          send += " "
        }
        message.channel.send("here:\n" + send)
      } else if (comma == "kys") {
        message.reply("no :)");
        giveAch("kys", "kys", message);
      } else if (comma == "invite") {
        update = false;
      } else if (comma == "count") {
        let send = "";
        fs.readFile('data.json', function(err, data){
          if (err) throw err
          var jsondata = JSON.parse(data);
          jsondata = jsondata.cc;
          const count = Object.fromEntries(
                Object.entries(jsondata).sort(([,a],[,b]) => b-a)
            );
          for (i in Object.keys(count)) {
            send += `**${Object.keys(count)[i]}:** ran ${count[Object.keys(count)[i]]} time${count[Object.keys(count)[i]] == 1 ? "" : "s"}\n`
            if (i > 10) break;
          }
          message.channel.send(send);
        })
      } else if (comma.startsWith("dbset")){
        fs.readFile('data.json', function(err, data){
          var jsondata = JSON.parse(data);
          var publicdb = jsondata.publicdb;
          var user = message.author.username;
          publicdb[user] = message.content.substring(8);
          jsondata.publicdb = publicdb;
          fs.writeFile('data.json', JSON.stringify(jsondata), function(err){
            message.reply("Updated!");
          })
        })
      } else if(comma.startsWith("dbread")){
        fs.readFile('data.json', function(err, data){
          if (err) throw err
          var jsondata = JSON.parse(data);
          var publicdb = jsondata.publicdb;
          var user = message.author.username;
          message.reply(publicdb[user]?publicdb[user]:"[empty]");
        })
      } else if(comma == "inccounter"){
        fs.readFile('data.json', function(err,data){
          var jsondata = JSON.parse(data);
          jsondata.counter++;
          fs.writeFile('data.json', JSON.stringify(jsondata), function(err){
            message.reply(`Updated! Counter is now ${jsondata.counter}`);
          })
        })
      } else {
        update = false;
        message.channel.send("unknown command. please try d?help")
      }
      comma = comma.split(" ")[0];
      if (update) setcount(comma);
      
    } // admin only commands

    // silly replies

    if (content.includes("<@1141709521878790235>")) {
      message.reply("SHUT UP WHAT DO YOU WANT");
    }
    if (content.includes("d²>d³") || content.includes("d2>d3")) {
      message.react("<:youfuckedup:1133438493738147942>")
      message.reply("shut the fuck up you little");
    }
    if (content.includes("d²<d³") || content.includes("d2<d3")) {
      message.react("<:thubm_up:1096323451985334363>")
    }
    if (content.includes("duck")) {
      message.react("🦆")
    }
    if (content.includes("dcubed") && content.includes(" slash commands")) {
      message.reply("no ")
      giveAch("no slash commands", "because no", message)
    }
    if(content == "HAHA YES I LEAKED ICOSAHEDRON TOKEN") message.reply("cool what is it")
    if (message.content.startsWith("d/") && message.author.id == devId) {
      const comma = message.content.substring(2);
      if (comma == "dma") {
        dma = !dma
        message.react("✅");
        if (dma) {
          message.react("🔛")
        } else {
          message.react("📴")
        }
      }
      if (comma == "dmc") {
        dmc = !dmc
        message.react("✅");
        if (dmc) {
          message.react("🔛")
        } else {
          message.react("📴")
        }
      }
      if (comma.startsWith("get")) {
        const toget = comma.substring(4)
        message.reply(`${eval(toget)}`)
      }
    }
    if (dma) {
      console.log(`${message.author.username}: ${message.author.id}`)
    }
    if (dmc) {
      console.log(`${message.author.username}: ${message.content}`)
    }
    
  }
  catch (err) {
    message.reply(`well dcubed ducked up: \`\`\`${err}\`\`\``);
  }
  // console.log(message)
})


// other stuff


client.login(process.env.token);
client.on('ready', (c) => {
  client.user.setActivity({
    name: `d?help to get started`,
    type: ActivityType.Custom
  })
  client.user.setPresence({ status: 'idle' });
  const zatkniskuritza = client.channels.cache.get("1217705835233284186");
  zatkniskuritza.send('Scanning messages...');
  zatkniskuritza.messages.fetch({ limit: 10000 }).then(messages => {
    console.log(`Received ${messages.size} messages`);
    let abc = "";
    messages.forEach(message => abc += message.content);
    fs.readFile('data.json', function(err, data){
      var jsondata = JSON.parse(data);
      
      fs.writeFile('data.json', JSON.stringify(jsondata), function(err){
        zatkniskuritza.send('Scanning complete.');
      })
    })
  })
  console.log("bot succsesfully connected");
})
let commandshelp = ["help", "shows all commands", "test", "test command used for debugging", "say", "make the bot say things", "ping", "shows the brain delay of dcubed", "yesorno", "answers a question with yes or no (there is a 0.5% chance you might see a secret!)", "tictactoe", "start a game of tic tac toe", "mess", "messes up your text", "achs", "shows your achievements", "achtest", "?", "whatsnew", "shows the recent changes about dcubed", "ver", "shows version", "credits", "credits", "gibberish", "send random gibberish", "count", "shows the top 10 most used commands starting at december 2023", "dbset", "stores your given value in the database", "dbread", "inputs the value stored in the database"]
let yesnod = ["yeah", "yes", "idk try again", "ABSOLUTELY", "yeah ig", "idk", "uh no", "NO. NEVER", "no???", "negative"]
let xogameopen = false
let xogamestarted = false
let pplplaying = []
let thonpl = 0
let ttt = [0, 0, 0, 0, 0, 0, 0, 0, 0]
function showgame() {
  let showst = "```"
  for (let j = 0; j <= 3; j++) {
    for (let i = 0; i < 3; i++) {
      if (ttt[i + (j - 1) * 3] == 0) {
        showst += "-";
      } else if (ttt[i + (j - 1) * 3] == 1) {
        showst += "O";
      } else {
        showst += "X";
      }
    }
    showst += "\n"
  }
  showst += "```type d?place numberpos to place,(example: `d?place 4`, counting starts from 1,from left to right, top to bottom)\ntype d?joinxog to join";
  return showst
}
const wi = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]
]
function checkforwinxo() {
  for (let i = 0; i < 8; i++) {
    if (ttt[wi[i][0]] == ttt[wi[i][1]] && ttt[wi[i][2]] == ttt[wi[i][1]] && (ttt[wi[i][1]] !== 0)) {
      xogameopen = false
      xogamestarted = false
      pplplaying = []
      thonpl = 0
      ttt = [0, 0, 0, 0, 0, 0, 0, 0, 0]
      return listofchars[ttt[wi[i][0]]] + " won!"
    }
  }
  if (ttt.includes(0)) {
    return "..."
  } else {
    return "welp no one won :/"
  }
}
let listofchars = ["O", "X"]
const achsdesc = {
  "test": "d?achtest",
  "won a tic tac toe game": "win a tic tac toe game",
  "secret message": "got the secret message in d?yesorno",
  "no slash commands": "ask dcubed why doesnt he use slash commands",
  "kys": "tell dcubed to kys"
}
// database test stuff
//db.set("key", "value");
//db.get("key").then(key => {
//  console.log(key)
//})
const devId = "1163914091270787125";
const helpedId = ["801078409076670494"]
const bannedId = ["979238733222137876"]
const saybannedId = [""]
const banReason = {
  "979238733222137876": "\"I'm an ASSHOLE!!!! I SUCK DICK IM AN ASSHOLE!!!! IM AN ASSHOLE!!!!!!I SUCK HUGE DICK!!!\"\n\"d?mess im na sashloeed?mess im na sashloeed?mess im na sashloeed?mess im na sashloeed?mess im na sashloeed?mess im na sashloeed?mess im na sashloee\"\n also hes a certified dumbass.com"
}
const dbot = {
  "ver": {

  }
}
dbot.ver.ver = "1.61";
dbot.ver.build = "1483"
dbot.ver.fullver = `${dbot.ver.ver}.20231210.${dbot.ver.build}`
const chlog = [{
  "ver": "1.5",
  "change": "added d?gibberish"
}, {
  "ver": "1.53",
  "change": "added d?invite\nattempted to fix tic tac toe"
}, {
  "ver": "1.54",
  "change": "added silly reply\nbot no longer ignores other bots"
}, {
  "ver": "1.56",
  "change": "fixed silly replies"
},{
  "ver": "1.6",
  "change": "added command count"
}]
// dm - dump message
// a - author
// c - content
let dma = false;
let dmc = false;

let vocal = ["a", "e", "i", "o", "u", "y"]
let conso = ["b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "z"];
function random(_a, _b) {
  if (_a > _b) {
    var _c = _a;
    _a = _b;
    _b = _c;
  }
  return Math.floor(Math.random() * (_b - _a + 1) + _a);
}
// app.get('/', (req, res) => res.redirect("https://dcubed.dateplays.repl.co/"));
const help = {
}
function setcount(n) {
  fs.readFile("data.json", (err, data) => {
    var jsondata = JSON.parse(data);
    if (!!jsondata.cc[n]) {
      jsondata.cc[n]++;
    } else {
      jsondata.cc[n] = 1;
    }
    fs.writeFile('data.json', JSON.stringify(jsondata), function (err) {
      if (err) throw err;
      // console.log(`${n} updated`);
    });
  })
}