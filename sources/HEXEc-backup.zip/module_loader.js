window.require = (function() {
	function requireModule(module) {
		if (require.cache[module]) return require.cache[module];
		// request
		let module_content = (function(path){
			let request = new XMLHttpRequest();
			request.open('GET', path, false);
			request.send(null);
			if (request.status !== 200 && request.status !== 301) throw `Unable to load module: "${path}" Status Code: ${request.status}`;
			return request.responseText;
		})(module);

		// run the module
		let module_exports = (function(content) {
			try {
				return JSON.parse(content);
			} catch {
				let mod = {exports: {}}
				let modfunction = new Function("module", content);
				modfunction(mod);
				return mod.exports;
			}
		})(module_content);
		require.cache[module] = module_exports;
		return module_exports;
	};
	requireModule.cache = {};
	// Use this to preload modules async
	requireModule.preload = async function(module) {
		let module_content = await (await fetch(module)).text();
		// run the module
		let module_exports = (function(content) {
			try {
				return JSON.parse(content);
			} catch {
				let mod = {exports: {}}
				let modfunction = new Function("module", content);
				modfunction(mod);
				return mod.exports;
			}
		})(module_content);
		return require.cache[module] = module_exports;
	}
	return requireModule;
})();
