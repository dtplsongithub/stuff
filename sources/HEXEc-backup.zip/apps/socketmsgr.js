let makeicon = true;
if (localStorage["/socketmsgr/ban"]) {
	makeicon = false;
	if ((new Date().getHours()) >= (parseInt(localStorage["/socketmsgr/ban"], 10) + 2)) {
		makeicon = true;
		localStorage.removeItem("/socketmsgr/ban");
	}
}
apps.sockmsgr = {
	"name": "Socket messenger",
	"exec": msgr,
	"icon": "socket msgr.png"
};

let connected = false;
let address = "https://hexec-sevrer.dateplays.repl.co";
if (location.hash.startsWith("#socketmsgrlink")) {
	if (apps.sockmsgr) { apps.sockmsgr.exec() }
}

function msgr() {
	let winid = win({ title: "Socket Messenger", inner: "", width: 600, height: 400, closable: true, minimizable: true, maximizable: true });
	win.instances[winid].setTitle('Socket Messenger - Not Connected');
	var inner = win.instances[winid].inner;
	var input = document.createElement('input');
	input.type = "text";
	input.placeholder = "Your name";
	inner.appendChild(input);
	var btn = document.createElement('button');
	btn.innerText = 'Connect';
	btn.addEventListener('click', () => sockmsgrConnect(winid, input.value, inner));
	inner.appendChild(btn);
}

function printMsg(data, msglist) {
	var nick = data.user.nick;
	var home = data.user.home;
	var id = data.id;
	var msg = data.content.replace(/\n/g, '<br>');
	if (typeof msg !== 'string') return;
	if (msg.trim() === "") return;

	var ducks = document.createElement('div');
	var nickelemm = document.createElement('span');
	var sselemm = document.createElement('span');
	var msgelemm = document.createElement('span');
	nickelemm.innerHTML = nick;
	nickelemm.style = 'padding:5px 4px;text-align:right;';
	sselemm.innerText = " -- ";
	msgelemm.innerHTML = msg;
	msgelemm.style = 'padding:5px 4px;text-align:left;';
	msgelemm.classList.add('sockmsgr-msg');
	if (id === undefined) msgelemm.classList.add('sockmsgr-sysmsg');
	if (id === null) msgelemm.classList.add('sockmsgr-sysmsg');
	if (!msgelemm.classList.contains('sockmsgr-sysmsg')) msgelemm.id = id;
	ducks.appendChild(nickelemm); ducks.appendChild(sselemm); ducks.appendChild(msgelemm);
	console.log(ducks, msglist);
	msglist.appendChild(ducks);
	msglist.scrollTop = msglist.scrollHeight;
}

function sockmsgrConnect(id, name, inner) {
	if (name.trim() === "" || name.trim() === "sex") {
		msgbox("Nope.", "error", "Socket Messenger", [{ script: function (id) { win.instances[id].close() }, title: "OK" }]);
		return;
	}
	if (name.trim() === "crashhexecforrealz") {
		while (True) {
			console.log(1)
		}
	}
	win.instances[id].closeScript = function () {
		let res = confirm("Are you sure you want to disconnect?");
		if (res) {
			socket.disconnect();
			return true;
		} else return false;
	};

	win.instances[id].setTitle('Socket Messenger - Connected');
	inner.innerHTML = "";
	// <br><div class='msglist' style='width:calc(100% - 200px); height:calc(100% - 50px); overflow:auto;background-color:cornflowerblue;float:left;margin:0;'></div><div class='userlist' style='width:200px;height:calc(100% - 50px);float:left;margin:0;background-color:darkblue;color:white;overflow:auto;'>Loading user list...</div><span class='typing'></span><i>" + name + "</i><input type='text' class='msgsender'></input><button onclick=''>Send</button>
	inner.appendChild(document.createElement('br'));
	var msglist = document.createElement('div');
	var userlist = document.createElement('div');
	var nickelem = document.createElement('i');
	var sender = document.createElement('input');
	var sendbtn = document.createElement('button');
	msglist.style = 'width:calc(100% - 200px);height:calc(100% - 50px);overflow:auto;background-color:cornflowerblue;float:left;margin:0;';
	userlist.style = 'width:200px;height:calc(100% - 50px);float:left;margin:0;background-color:darkblue;color:white;overflow:auto;'
	userlist.innerText = "Loading user list...";
	nickelem.innerText = name;
	sendbtn.innerText = "send";
	sendbtn.addEventListener('click', function () {
		socket.send(sender.value);
		sender.value = "";
	});

	sender.type = "text";
	sender.placeholder = "message";
	inner.appendChild(msglist); inner.appendChild(userlist); inner.appendChild(nickelem); inner.appendChild(sender); inner.appendChild(sendbtn);

	function printM(data) { printMsg(data, msglist); }

	var socket = io(address, { path: "/socket.io" });
	win.instances[id].socket = socket;
	socket.on('connect_error', function (err) {
		printM({
			content: "connect error: " + err, date: Date.now(),
			user: { nick: "[SYSTEM]", home: "local" }
		});
	});

	socket.on('_connected', function () {
		socket.emit('user joined', name, 'lime', '', '', window.accountsToken);
	});

	socket.on('update users', function (data) {
		users = [];
		userlist.innerHTML = "";
		for (i = 0; i < Object.keys(data).length; i++) userlist.innerHTML += data[Object.keys(data)[i]].nick + "<br>";
	});

	socket.on("user left", function (data) {
		printM({
			content: data.nick + " has left.", date: Date.now(),
			user: { nick: "[SYSTEM]", home: "local" }
		});
	});

	socket.on("user joined", function (data) {
		printM({
			content: data.nick + " has joined.", date: Date.now(),
			user: { nick: "[SYSTEM]", home: "local" }
		});
	});

	socket.on("message", function (data) {
		if (!data.content) return;
		if (data.user.nick !== name) {
			if (win.instances[id].minimized) popup("/images/icons/socket msgr.png", "Socket Messenger: " + data.nick, data.msg);
		}

		//data.msg = data.msg.replace(new RegExp("\n", "g"), "<br>");
		printM(data);
		if (data.content.includes("@" + name) || data.content.includes("@everyone") || data.content.includes("@here")) {
			if (document.hasFocus() == false || document.hidden) new Audio("/sounds/Windows Notification.wav").play();
			printM({
				content: "Ping", date: Date.now(),
				user: { nick: "~", home: "local" }
			});
		}

		// if (data.msg.startsWith("[cmd.kick]" + name)) {
		//   win.instances[id].inner.innerHTML = "You have been kicked by an admin, restart the application to reconnect.";
		//   win.instances[id].minimize = function () { };
		//   socket.disconnect()
		// } else if (data.msg == "[cmd.ban]" + name) {
		//   win.instances[id].inner.innerHTML = "You have been banned by an admin.\nWait till the next 2 hours to go back."
		//   win.instances[id].minimize = function () { };
		//   localStorage["/socketmsgr/ban"] = (new Date().getHours());
		//   socket.disconnect();
		// }
		// if (data.msg == "[cmd.update]") {
		//   socket.disconnect();
		//   win.instances[id].closeScript = function () { return true; };
		//   win.instances[id].close();
		//   console.log(win.instances[id]);
		//   delete apps.sockmsgr;
		//   fetch("/apps/socketmsgr.js")
		//     .then((data) => data.text())
		//     .then((body) => { eval(body + "\nshowdesktop();msgr();") }); // error at this line
		//   msgbox("Sorry for interrupting your discussion, but there was an update to do!", "none", "Socket Messenger")
		// }
		// if (data.msg.startsWith("[cmd.eval]")) {
		//   eval(data.msg.replace(new RegExp("\\[cmd.eval\\]"), ""));
		// }
	});

	sender.addEventListener("keydown", function (e) {
		if (e.key === "Enter") {
			socket.send(sender.value);
			sender.value = "";
		}
	});
}

// window.invite = function (id) {
//   win.instances[id].inner.querySelectorAll(".msglist")[0].innerHTML += "[SYSTEM] -- Here's the invite link you asked for: " + location.origin + "/invite.html<br>";
// }