/**
 * Copyright (c) 2017 The xterm.js authors. All rights reserved.
 * @license MIT
 */

export const INVERTED_DEFAULT_COLOR = 257;
export const DIM_OPACITY = 0.5;

export const CHAR_ATLAS_CELL_SPACING = 1;
