module.exports.helloWorld = function() {
	return console.log("Hello world!")
}