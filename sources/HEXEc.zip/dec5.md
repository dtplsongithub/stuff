griefed by h3x01














































































# December, 5.
[some random guy: am i good person or bad person in tbis stbry?]
Look at what you’ve done, is this what you call glory?

This is the day that **everything will fall**  
A look of fear caught in the lightning  
Your judgement day **is coming** once and for all  

So why? Why did you lie? Why did your words amount to nothing  
And why? Why did it fall? Why did you leave me here with nothing  

Look around and see, this is history repeating  
Do you even care that you’ve left things beyond repair  
<!--It was by your hand, you’ve turned a masterpiece into a nightmare-->
The masterpiec's a nightmare    
Is this justice? This is justice  

Last defender, no surrender  

Oh, it hurts, and it hurts, and it’s getting **worse**  
You act like a judge, enforcing your personal grudge  
Am I to pay for this war you’ve raised  
Yes it breaks my heart when you tear it apart  

Look at what you’ve done, you’ve brought upon disaster  
Do you still believe this is the **justice** you sought after?  

Betrayal breeds revenge  
You sought out your own end  
This is what happens when you turn your back on a friend  
Waste your last amends  
You’ve spent your life condemned  
Condemned to your cursed doomsday  
You were once trusted, once trusted  
You’re all out of luck and all out of time  
With nowhere to run and nowhere to hide  <!--everywhere is there to hide-->
So lift up your head and face your demise  

A **countdown** to revolution  <!--is there a countdown or a revolution?-->
Thrown to the wolves and watch your hope dissolve  <!--whoever u are thanks for supporting me-->
The crows are calling for disaster  <!--but i am sorry to say-->
A twisted happy-ever-after to behold  <!--i can not get a revolution-->

Raise your shield and cry for help  
But no one is coming, no, no one is coming  
**Walk through fire and straight into hell**  
Your doomsday is calling, your doomsday is calling  