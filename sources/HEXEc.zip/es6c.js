import * as os from 'os'; 
import * as math from 'math';
// import * as os from 'os';
import * as time from 'time';
var _pj;
var bLine, basicgraph, graph, name, repeats;
function _pj_snippets(container) {
    function in_es6(left, right) {
        if (((right instanceof Array) || ((typeof right) === "string"))) {
            return (right.indexOf(left) > (- 1));
        } else {
            if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                return right.has(left);
            } else {
                return (left in right);
            }
        }
    }
    function set_properties(cls, props) {
        var desc, value;
        var _pj_a = props;
        for (var p in _pj_a) {
            if (_pj_a.hasOwnProperty(p)) {
                value = props[p];
                if (((((! ((value instanceof Map) || (value instanceof WeakMap))) && (value instanceof Object)) && ("get" in value)) && (value.get instanceof Function))) {
                    desc = value;
                } else {
                    desc = {"value": value, "enumerable": false, "configurable": true, "writable": true};
                }
                Object.defineProperty(cls.prototype, p, desc);
            }
        }
    }
    container["in_es6"] = in_es6;
    container["set_properties"] = set_properties;
    return container;
}
_pj = {};
_pj_snippets(_pj);
class bcolors {
}
_pj.set_properties(bcolors, {"BOLD": "\u001b[1m", "ENDC": "\u001b[0m", "FAIL": "\u001b[91m", "HEADER": "\u001b[95m", "OKBLUE": "\u001b[94m", "OKCYAN": "\u001b[96m", "OKGREEN": "\u001b[92m", "UNDERLINE": "\u001b[4m", "WARNING": "\u001b[93m"});
graph = ".............................................\n.............................................\n.............................................\n.............................................\n.............................................\n.............................................\n....................................***......\n.................................***.........\n..............................***............\n...........................***...............\n........................***..................\n.....................***.....................\n..................***........................\n...............***...........................\n............***..............................\n.........***.................................\n......***....................................\n...***.......................................\n***..........................................\n**............................................\n..........................................***\n.......................................***...\n....................................***......".replace("*", "");
function plotAtXy(graph, x, y, appendLetter) {
    /*'Assuming X Y (0,0) is in top left.
    To convert . to * in graph do
    ............
    ............
    ............
    ............
    ............
    and appendLetter = "\b\*"
    (y and x column length must be even)*/
    var graphActualX, graphActualY, graphLenX, graphLenY, graphXZero, graphYZero;
    graph = graph.split("\n");
    for (var something = 0, _pj_a = (graph.length - 1); (something < _pj_a); something += 1) {
        graph[something] = function () {
    var _pj_b = [], _pj_c = graph[something];
    for (var _pj_d = 0, _pj_e = _pj_c.length; (_pj_d < _pj_e); _pj_d += 1) {
        var x = _pj_c[_pj_d];
        _pj_b.push(x);
    }
    return _pj_b;
}
.call(this);
    }
    graphLenX = graph[0].length;
    graphLenY = graph.length;
    graphXZero = (graphLenX / 2);
    graphYZero = (graphLenY / 2);
    graphActualX = (graphXZero + x);
    graphActualY = (graphYZero + y);
    graph[y][x] = (graph[y][x] + appendLetter);
    for (var i = 0, _pj_a = graph.length; (i < _pj_a); i += 1) {
        graph[i] = "".join(graph[i]);
    }
    graph = "\n".join(graph);
    return graph;
}
function actualPlotAtXy(graph, x, y, appendLetter) {
    var act_g, act_x, act_y, x_len, y_len;
    if (((x >= graph.count("\n")) || (y >= graph.split("\n")[0].count(graph[0])))) {
        document.write(("[warn:37] Out of graph: " + [x, y].toString()));
        return graph;
    }
    /* This converts values so that X, Y given (0,0) (plotted at -90, 90) becomes (90, 90) (plotted at 0, 0) (center), then calls plotAtXy.. */
    act_g = graph;
    graph = graph.toString().split("\n");
    x_len = graph[0].length;
    y_len = graph.length;
    act_x = ((x_len / 2) + x);
    act_y = ((y_len / 2) - y);
    return plotAtXy(act_g, Number.parseInt(act_x), Number.parseInt(act_y), appendLetter);
}
bLine = ".............................................\n";
repeats = Number.parseInt((bLine.length / 2));
basicgraph = (bLine * repeats);
function allPointsBetween(x1, y1, x2, y2) {
    var currXadd, currYadd, dx, dy, pointGraphArr;
    dy = (y2 - y1);
    dx = (x2 - x1);
    currXadd = 0;
    currYadd = 0;
    pointGraphArr = [[x1, y1]];
    while (true) {
        currXadd += dx;
        currYadd += dy;
        pointGraphArr.append([currXadd, currYadd]);
        if ((pointGraphArr[(pointGraphArr.length - 1)][0] > x2)) {
            pointGraphArr.pop();
            return pointGraphArr;
        }
    }
}
function allPointsBetween_int(x1, y1, x2, y2, accuracy) {
    /*Does not use allPointsBetween()
    Requires extra parameter accuracy (1=default)
    Returns in integer.*/
    var currXadd, currYadd, dx, dy, pointGraphArr;
    dy = (y2 - y1);
    dx = (x2 - x1);
    currXadd = 0;
    currYadd = 0;
    pointGraphArr = [[x1, y1]];
    while (true) {
        currXadd += (dx / accuracy);
        currYadd += (dy / accuracy);
        pointGraphArr.append([Number.parseInt(currXadd), Number.parseInt(currYadd)]);
        if ((pointGraphArr[(pointGraphArr.length - 1)][0] > x2)) {
            pointGraphArr.pop();
            return pointGraphArr;
        }
    }
}
function allPointsBetween_float(x1, y1, x2, y2, accuracy) {
    /*Does not use allPointsBetween()
    Requires extra parameter accuracy (1=default)
    Returns in float.*/
    var currXadd, currYadd, dx, dy, pointGraphArr;
    dy = (y2 - y1);
    dx = (x2 - x1);
    currXadd = 0;
    currYadd = 0;
    pointGraphArr = [[x1, y1]];
    while (true) {
        currXadd += (dx / accuracy);
        currYadd += (dy / accuracy);
        pointGraphArr.append([Number.parseFloat(currXadd), Number.parseFloat(currYadd)]);
        if ((pointGraphArr[(pointGraphArr.length - 1)][0] > Number.parseFloat(x2))) {
            pointGraphArr.pop();
            return pointGraphArr;
        }
    }
}
function plotLine(graph, x1, x2, y1, y2, mode = "integer", accuracy = 4, appendLetter = "*") {
    /*Plots a line on the graph.
    Parameters:
    graph, x1, x2, y1, y2, mode='integer', accuracy=4, appendLetter="*"*/
    var graphPoints;
    if ((mode === "integer")) {
        graphPoints = allPointsBetween_int(x1, x2, y1, y2, accuracy);
    } else {
        if ((mode === "float")) {
            graphPoints = allPointsBetween_float(x1, x2, y1, y2, accuracy);
        } else {
        }
    }
    for (var point, _pj_c = 0, _pj_a = graphPoints, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        point = _pj_a[_pj_c];
        try {
            graph = actualPlotAtXy(graph, point[0], point[1], appendLetter);
        } catch(e) {
            document.write(("[warn:195] Out of graph: " + point.toString()));
        }
    }
    return graph;
}
function graphOneFunctionPoint(func_rule, numInp) {
    /* clarification: doesn't graph it  */
    var funcSolveFor;
    func_rule = func_rule.split(" = ")[1];
    if (_pj.in_es6("x", func_rule.split(" = ")[0])) {
        funcSolveFor = "x";
    } else {
        funcSolveFor = "y";
    }
    func_rule = func_rule.replace(funcSolveFor, numInp);
    func_rule = eval(func_rule);
    return func_rule;
}
function allFunctionPoints(func_rule, rangestart, rangeend) {
    /*note; all must be str()d even int, float
    inclusive rangestart exclusive rangeend*/
    var output;
    output = [];
    if (_pj.in_es6("x", func_rule.split(" = ")[0])) {
        for (var x = Number.parseInt(rangestart), _pj_a = Number.parseInt(rangeend); (x < _pj_a); x += 1) {
            output.append([x, graphOneFunctionPoint(func_rule, x.toString())]);
        }
    } else {
        for (var y = Number.parseInt(rangestart), _pj_a = Number.parseInt(rangeend); (y < _pj_a); y += 1) {
            output.append([y, graphOneFunctionPoint(func_rule, y.toString())]);
        }
    }
    return output;
}
function plotFunction(graph, func_rule, rangestart, rangeend, appendLetter = "*") {
    /*Plots a line on the graph.
    Parameters:
    graph, x1, x2, y1, y2, mode='integer', accuracy=4, appendLetter="*"*/
    var graphPoints;
    graphPoints = allFunctionPoints(func_rule, rangestart, rangeend);
    for (var point, _pj_c = 0, _pj_a = graphPoints, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        point = _pj_a[_pj_c];
        try {
            graph = actualPlotAtXy(graph, point[0], point[1], appendLetter);
        } catch(e) {
            document.write(("[warn:262] Out of graph: " + point.toString()));
        }
    }
    return graph;
}
function combineTwoLists(a, b) {
    function () {
    var _pj_a = [], _pj_b = b;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        _pj_a.push(a.append(x));
    }
    return _pj_a;
}
.call(this);
    return a;
}
function intersection(a, b) {
    return function () {
    var _pj_a = [], _pj_b = a;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if (_pj.in_es6(x, b)) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
}
function union(a, b) {
    return combineTwoLists(function () {
    var _pj_a = [], _pj_b = a;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((! _pj.in_es6(x, b))) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this), function () {
    var _pj_e = [], _pj_f = b;
    for (var _pj_g = 0, _pj_h = _pj_f.length; (_pj_g < _pj_h); _pj_g += 1) {
        var x = _pj_f[_pj_g];
        if ((! _pj.in_es6(x, a))) {
            _pj_e.push(x);
        }
    }
    return _pj_e;
}
.call(this));
}
function subset(a, b) {
    return (function () {
    var _pj_a = [], _pj_b = a;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if (_pj.in_es6(x, b)) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this) === a);
}
function strictSubset(a, b) {
    return ((function () {
    var _pj_a = [], _pj_b = a;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if (_pj.in_es6(x, b)) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this) === a) && (a !== b));
}
function notSubset(a, b) {
    return (! subset(a, b));
}
function superset(a, b) {
    return subset(b, a);
}
function strictSuperset(a, b) {
    return strictSubset(b, a);
}
function notSuperset(a, b) {
    return notSubset(b, a);
}
function powerset(a) {
    return (2 ^ a.length);
}
function equality(a, b) {
    return (a === b);
}
function complement(a, b) {
    return function () {
    var _pj_a = [], _pj_b = b;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((! _pj.in_es6(x, a))) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
}
function difference(a, b) {
    return function () {
    var _pj_a = [], _pj_b = b;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((! _pj.in_es6(x, a))) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
}
function symmetricDifference(a, b) {
    return function () {
    var _pj_a = [], _pj_b = combineTwoLists(a, b);
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((! _pj.in_es6(x, intersection(a, b)))) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
}
function setMembership(elem, a) {
    return (function () {
    var _pj_a = [], _pj_b = a;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((x === elem)) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this).length === 1);
}
function noSetMembership(elem, a) {
    return (function () {
    var _pj_a = [], _pj_b = a;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((x === elem)) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this).length === 0);
}
function cartesianProduct(a, b) {
    return zip(a, b);
}
function cardinality(a) {
    return a.length;
}
function lstsplice(a, b, c) {
    return function () {
    var _pj_a = [], _pj_b = range(b, c);
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var i = _pj_b[_pj_c];
        _pj_a.push(a[i]);
    }
    return _pj_a;
}
.call(this);
}
function allSubsets(a) {
    var x, y;
    x = function () {
    var _pj_a = [], _pj_b = range(0, (a.length - 1));
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var i = _pj_b[_pj_c];
        _pj_a.push(lstsplice(a, 0, i).sort());
    }
    return _pj_a;
}
.call(this);
    y = [];
    function () {
    var _pj_a = [], _pj_b = x;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var i = _pj_b[_pj_c];
        if ((! _pj.in_es6(i, y))) {
            _pj_a.push(y.append(i));
        }
    }
    return _pj_a;
}
.call(this);
    return y;
}
function generateSet(type1, start, end) {
    if ((type1 === "integer")) {
        return function () {
    var _pj_a = [], _pj_b = range(start, end);
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        _pj_a.push(x);
    }
    return _pj_a;
}
.call(this);
    } else {
        if ((type1 === "whole")) {
            return function () {
    var _pj_a = [], _pj_b = range(0, end);
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        _pj_a.push(x);
    }
    return _pj_a;
}
.call(this);
        } else {
        }
    }
}
function operationTwoLists(list1, list2, operation) {
    var output;
    output = [];
    for (var something = 0, _pj_a = list1.length; (something < _pj_a); something += 1) {
        if ((operation === "+")) {
            output.append((list1[something] + list2[something]));
        } else {
            if ((operation === "-")) {
                output.append((list1[something] - list2[something]));
            } else {
                if ((operation === "/")) {
                    output.append((list1[something] / list2[something]));
                } else {
                    if ((operation === "*")) {
                        output.append((list1[something] * list2[something]));
                    } else {
                        throw new ValueError((("Invalid operation: " + operation.toString()) + ". Can only be - + * or /."));
                    }
                }
            }
        }
    }
    return output;
}
function operationMatrices(matrice1, matrice2, operation) {
    var output;
    output = [];
    for (var something = 0, _pj_a = matrice1.length; (something < _pj_a); something += 1) {
        output.append(operationTwoLists(matrice1[something], matrice2[something], operation));
    }
    return output;
}
function negativeMatrice(matrice1) {
    var output, something2, tmp;
    output = [];
    tmp = [];
    for (var something, _pj_c = 0, _pj_a = matrice1, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        something = _pj_a[_pj_c];
        for (var something2, _pj_f = 0, _pj_d = something, _pj_e = _pj_d.length; (_pj_f < _pj_e); _pj_f += 1) {
            something2 = _pj_d[_pj_f];
            something2 = (- something2);
            tmp.append(something2);
        }
        output.append(tmp);
        tmp = [];
    }
    return output;
}
function determinant2x2Matrix(matrice1) {
    var a, b, c, d, output;
    a = matrice1[0][0];
    b = matrice1[0][1];
    c = matrice1[1][0];
    d = matrice1[1][1];
    output = ((a * d) - bc);
    return output;
}
function sidewaysDotPlot(graph_array, appendLetter = "*", xval = "", yval = "") {
    var output, stars, x;
    output = "";
    x = 0;
    for (var something, _pj_c = 0, _pj_a = graph_array, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        something = _pj_a[_pj_c];
        x += 1;
        stars = (appendLetter * something[1]);
        output += ((x.toString() + " |") + stars);
        output += "\n";
    }
    output += [xval, yval].toString();
    return output;
}
function sidewaysBarGraph(graph_array, appendLetter = "|", xval = "", yval = "") {
    /* Same as sidewaysDotPlot but appendLetter is | */
    var output, stars, x;
    output = "";
    x = 0;
    for (var something, _pj_c = 0, _pj_a = graph_array, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        something = _pj_a[_pj_c];
        x += 1;
        stars = (appendLetter * something[1]);
        output += ((x.toString() + " |") + stars);
        output += "\n";
    }
    output += [xval, yval].toString();
    return output;
}
function mean(lst) {
    return (sum(lst) / lst.length);
}
function median(x) {
    var f, f1, f2, o, y;
    y = sorted(x);
    if (((y.length % 2) !== 0)) {
        return y[Number.parseInt((y.length / 2))];
    } else {
        f = (y.length / 2);
        f1 = y[(Number.parseInt(f) - 1)];
        f2 = y[Number.parseInt(f)];
        o = mean([f1, f2]);
        return o;
    }
}
function beforeAfterLst(lst, one) {
    var l1, l1_s1, l1_s2, l2, l2_s1, l2_s2;
    one = median(lst);
    l1 = function () {
    var _pj_a = [], _pj_b = lst;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((x < one)) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
    l2 = function () {
    var _pj_a = [], _pj_b = lst;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((x > one)) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
    l1_s1 = function () {
    var _pj_a = [], _pj_b = l1;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((x < median(l1))) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
    l1_s2 = function () {
    var _pj_a = [], _pj_b = l1;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((x < median(l1))) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
    l2_s1 = function () {
    var _pj_a = [], _pj_b = l1;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((x < median(l2))) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
    l2_s2 = function () {
    var _pj_a = [], _pj_b = l1;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((x < median(l2))) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
    return [l1, l2, l1_s1, l1_s2, l2_s1, l2_s2];
}
function boxPlot(graph_array, outputType = "array") {
    var output, outputJSON, q1, q2, q3, split1, split3, threes, whisker1, whisker2;
    graph_array = sorted(graph_array);
    q2 = Number.parseInt(median(graph_array));
    threes = beforeAfterLst(graph_array, q2);
    split1 = threes[0];
    split3 = threes[1];
    q1 = median(split1);
    q3 = median(split3);
    whisker1 = graph_array[0];
    whisker2 = graph_array[1];
    output = [["q1", q1], ["q2", q2], ["q3", q3], ["split1", split1], ["split3", split3], ["sorted", graph_array], ["whisker1", whisker1], ["whisker2", whisker2], ["l1_s1", threes[2]], ["l1_s2", threes[3]], ["l2_s1", threes[4]], ["l2_s2", threes[5]]];
    outputJSON = {"q1": q1, "q2": q2, "q3": q3, "split1": split1, "split3": split3, "sorted": graph_array, "whisker1": whisker1, "whisker2": whisker2, "l1_s1": threes[2], "l1_s2": threes[3], "l2_s1": threes[4], "l2_s2": threes[5]};
    if ((outputType !== "array")) {
        return outputJSON;
    } else {
        return output;
    }
}
function total(lst) {
    var output;
    output = 0;
    for (var x, _pj_c = 0, _pj_a = lst, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        x = _pj_a[_pj_c];
        output += x;
    }
    return output;
}
function length(lst) {
    return (lst.length + 1);
}
function mean(lst) {
    return (sum(lst) / lst.length);
}
function median(x) {
    var f, f1, f2, o, y;
    y = sorted(x);
    if (((y.length % 2) !== 0)) {
        return y[Number.parseInt((y.length / 2))];
    } else {
        f = (y.length / 2);
        f1 = y[(Number.parseInt(f) - 1)];
        f2 = y[Number.parseInt(f)];
        o = mean([f1, f2]);
        return o;
    }
}
function min(lst) {
    return sorted(lst)[0];
}
function max(lst) {
    return sorted(lst)[(sorted(lst).length - 1)];
}
function quartile(lst, num) {
    var z;
    if ((num === 2)) {
        return median(lst);
    } else {
        if ((num === 4)) {
            return max(lst);
        } else {
            if ((num === 1)) {
                z = function () {
    var _pj_a = [], _pj_b = lst;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((x < median(lst))) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
                return median(z);
            } else {
                if ((num === 3)) {
                    z = function () {
    var _pj_a = [], _pj_b = lst;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((x > median(lst))) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
                    return median(z);
                } else {
                    throw new Error("Must be in range(1,4).");
                }
            }
        }
    }
}
function quantile(lst, num) {
    if ((num === 0)) {
        return min(lst);
    } else {
        if ((num === 1)) {
            return max(lst);
        } else {
            throw new Error("Must be 0 or 1.");
        }
    }
}
function stdevp(lst) {
    var arlst, p, z;
    p = mean(lst);
    arlst = [];
    for (var x, _pj_c = 0, _pj_a = lst, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        x = _pj_a[_pj_c];
        z = (x - p);
        arlst.append((z * z));
    }
    return math.sqrt(mean(arlst));
}
function stdev(lst) {
    var arlst, p;
    p = mean(lst);
    arlst = function () {
    var _pj_a = [], _pj_b = lst;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        _pj_a.push(abs((x - p)));
    }
    return _pj_a;
}
.call(this);
    arlst = function () {
    var _pj_a = [], _pj_b = arlst;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        _pj_a.push((x * x));
    }
    return _pj_a;
}
.call(this);
    return math.sqrt(mean(arlst));
}
function mad(lst) {
    var z;
    z = function () {
    var _pj_a = [], _pj_b = lst;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        _pj_a.push(abs((x - mean(lst))));
    }
    return _pj_a;
}
.call(this);
    return mean(z);
}
function covp(lst) {
    return (stdevp(lst) / length(lst));
}
function filterout(lst) {
    return function () {
    var _pj_a = [], _pj_b = lst;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if (((Object.getPrototypeOf(x) !== str) && (x >= 0))) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
}
function transform(lst) {
    var y;
    y = [];
    function () {
    var _pj_a = [], _pj_b = lst;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((! _pj.in_es6(x, y))) {
            _pj_a.push(y.append(x));
        }
    }
    return _pj_a;
}
.call(this);
    return sorted(y);
}
function reverselt(lst) {
    document.write("Unsupported");
}
function mean_calc(lst) {
    lst = list(lst);
    return (sum(lst) / lst.length);
}
function subt_null(lst) {
    return function () {
    var _pj_a = [], _pj_b = lst;
    for (var _pj_c = 0, _pj_d = _pj_b.length; (_pj_c < _pj_d); _pj_c += 1) {
        var x = _pj_b[_pj_c];
        if ((x !== null)) {
            _pj_a.push(x);
        }
    }
    return _pj_a;
}
.call(this);
}
function tcsv_conv(lst) {
    var x;
    x = "";
    for (var something, _pj_c = 0, _pj_a = lst, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        something = _pj_a[_pj_c];
        for (var something2, _pj_f = 0, _pj_d = something, _pj_e = _pj_d.length; (_pj_f < _pj_e); _pj_f += 1) {
            something2 = _pj_d[_pj_f];
            x += (something2.toString() + ",");
        }
        x = x.slice(0, (- 1));
        x += "\n";
    }
    return x;
}
function add__list(lst) {
    var x;
    x = 0;
    for (var y, _pj_c = 0, _pj_a = lst, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        y = _pj_a[_pj_c];
        try {
            x += y;
        } catch(e) {
        }
    }
    return x;
}
function exit(one) {
    exit(0);
}
document.write(bcolors.HEADER);
document.write("<calculator v1.2>");
name = input("username: ");
function list(x) {
    var v;
    v = x.split(",");
    for (var i = 0, _pj_a = v.length; (i < _pj_a); i += 1) {
        try {
            v[i] = Number.parseInt(v[i]);
        } catch(e) {
            try {
                v[i] = Number.parseFloat(v[i]);
            } catch(e) {
            }
        }
    }
}
os.system("clear");
document.write(((bcolors.HEADER + "[Calculator] Type help('1') for help.") + bcolors.ENDC));
function help(one) {
    if ((one === "1")) {
        document.write("help('basics') - Help on basic stuff.");
        document.write("help('multiline') - Help on using multiline programs.");
        document.write("help('bool') - Help on booleans.");
        document.write("help('testgraph') - Help on the graphing calculator component (testgraph.py).");
        document.write("help('set-theory') - Help on the set theory component (set-theory.py).");
        document.write("help('matrice') - Help on the matrice component (matrice.py).");
        document.write("help('graph_plots') - Help on the plot graphing component (graph_plots.py).");
        document.write("help('desm') - Help on an attempt to clone desmos (desmos but python.py).");
        document.write("help('listcalc') - Help on the list calculator component (calculatory.py).");
    } else {
        if ((one === "testgraph")) {
            document.write("GRAPHING HELP\n___");
            document.write("plotAtXy(graph, x, y, appendLetter)             Plot a function. A prebuilt graph is in variable `graph.");
            document.write("                                                The point at X, Y on graph `graph` (a text graph) is changed");
            document.write("                                                to the letter appendLetter.");
            document.write("actualPlotAtXy(graph, x, y, appendLetter)       This is the one you should use, since it has bug fixes.");
            document.write("                                                Basically plotAtXy but better.");
            document.write("allPointsBetween(x1, y1, x2, y2)                This will get all points in between the coordinates x1, y1 and x2, y2.");
            document.write("allPointsBetween_float(x1, y1, x2, y2, accuracy)Difference: It gets all the points in between x1, y1, x2, y2 but it allows decimals.");
            document.write("                                                So you can specify an accuracy.");
            document.write("allPointsBetween_int(x1, y1, x2, y2, accuracy)  Think about it this way; It gets everything from allPointsBetween_float");
            document.write("                                                but rounds the decimals to the nearest- i mean lower- number.");
            document.write("Do help('testgraph-2') for page 2.");
        } else {
            if ((one === "multiline")) {
                document.write("MULTILINE HELP\n___");
                document.write("multiline del                  Deletes all stored multiline code.");
                document.write("multiline rd                   Reads multiline code.");
                document.write("multiline exec                 Executes multiline code.");
                document.write("multiline add [text]           Adds text to multiline. (new line)");
            } else {
                if ((one === "bool")) {
                    document.write("BOOLEAN HELP\n___");
                    document.write("bool x is less than y?                 x is smaller than y?");
                    document.write("bool x is equal to y?                 X = Y?");
                    document.write("bool x is y?                          x is y (or x = y?)?");
                    document.write("bool x-1 = x+1 = x?                   x - 1 is x + 1 is x?");
                    document.write("bool x is in list('1,2,3')?           is x in the list 1,2,3?");
                    document.write("bool x is greater than or equal to y? is x greater than or equal to y?");
                    document.write("bool x is less than or equal to y?    is x less than or equal to y?");
                    document.write("bool x is not equal to y?             is x not equal to y?");
                } else {
                    if ((one === "basics")) {
                        document.write("BASIC HELP\n___");
                        document.write("statement x = [1,2,3]");
                        document.write("        Make a list x which has the values 1, 2, and 3.");
                        document.write("statement x = 1");
                        document.write("        Make a variable x which is set to 1.");
                        document.write("statement y = 2 + 3");
                        document.write("        Make a variable y which is set to 2 + 3 (or 5).");
                        document.write("statement z = 'word'");
                        document.write("        Make a variable z set to word (word)");
                        document.write("x+z, x-z, x/z, x*z");
                        document.write("        Add, subtract, divide, or multiply x by z");
                    } else {
                        if ((one === "testgraph-2")) {
                            document.write("GRAPHING HELP [PAGE 2]\n___");
                            document.write("plotLine(graph, x1, x2, y1, y2, mode='integer',   Plots a line in graph from x1,y1 to x2,y2");
                            document.write("accuracy=4, appendLetter='*')                     Use mode='integer' & specify a accuracy. If you");
                            document.write("                                                  want to know what appendLetter is, check plotAtXy's docs on page 1.");
                            document.write("plotFunction(func_rule,                           Func_rule is the rule the function follows, e.g. 'f(x) = x + 1'.");
                            document.write("   rangestart, rangeend,                          Rangestart and rangeend are the y-values you want to plot on the graph to and fro; like");
                            document.write("                                                  -100, 100.");
                            document.write("   appendLetter='*'                               < See plotAtXy for definition of appendLetter.");
                            document.write("Thats all!");
                        } else {
                            if ((one === "set-theory")) {
                                document.write("SET THEORY HELP\n___");
                                document.write("Here are the set theory symbols and the corresponding function names.");
                                document.write("intersection(a,b)                                      a\u22c2b       \nunion(a,b)                                             a\u22c3b       \nsubset(a,b)                                            a\u2286b      \nstrictSubset(a,b)                                      a\u2282b     \nnotSubset(a,b)                                         a\u2284b       \nsuperset(a,b)                                          a\u2287b      \nstrictSuperset(a,b)                                    a\u2283b      \nallSubsets(a)                                          P(a)\n                                                       WARNING Does not include empty set {} and includes sets twice sometimes (e.g. {1,2}, {2,1})\n(already in python) a == b                             a=b       \nDNE (you can use complement(a,b) considering b is all the numbers in the world) A', Ac\ncomplement(a,b), (RECCOMMENDED)difference(a,b)         A-B, A\\B\nsymmetricDifference(a,b)                               A\u2296B, A\u2206B\n(already in python) a in A                             a\u2208A      \n(already in python) x not in A                         x\u2209A       \ncartesianProduct(a,b) (might not be correct)           A\u00d7B\ncardinality(a) (also exists in python: len(a))         |A|, #A   ");
                            } else {
                                if ((one === "matrice")) {
                                    document.write("MATRIX HELP\n___");
                                    document.write("Lists are written in this way:");
                                    document.write(" [ [1,2,3],");
                                    document.write("   [4,5,6],");
                                    document.write("   [7,8,9] ]");
                                    document.write("operationTwoLists(list1, list2, operation)        Preform a operation on two matrices.");
                                    document.write("operationMatrices(matrice1, matrice2, operation)  I forgor what this does if you really need it then ask me in a comment");
                                    document.write("negativeMatrice(matrice1)                         Makes all values in a matrice negative.");
                                    document.write("determinant2x2Matrix(matrice1)                    Get a determinant of a 2x2 matrix.");
                                } else {
                                    if ((one === "graph_plots")) {
                                        document.write("PLOTS HELP\n___");
                                        document.write("sidewaysDotPlot(graph_array, appendLetter=\"*\", xval=\"\", yval=\"\")");
                                        document.write("      graph_array: The list you want to plot");
                                        document.write("      appendLetter: If it's *, the graph will look something like");
                                        document.write("      xval | *********");
                                        document.write("      [2]  | ******* etc..");
                                        document.write("      xval, yval: X and Y axis labels.");
                                        document.write("sidewaysBarGraph(graph_array, appendLetter=\"|\", xval=\"\", yval=\"\"):");
                                        document.write("      Like sidewaysDotPlot but its a bar graph.");
                                        document.write("mean(x), median(x)");
                                        document.write("      Get mean and median of list.");
                                        document.write("beforeAfterLst(lst, one)");
                                        document.write("      I forgor what this does, but if you really need it ask me in a comment.");
                                        document.write("boxPlot(graph_array, outputType='array')");
                                        document.write("      graph_array: List of values");
                                        document.write("      outputType: the type of output you want (JSON for JSON or 'array' for list).");
                                    } else {
                                        if ((one === "desm")) {
                                            document.write("DESMOS CLONE HELP\n___");
                                            document.write("total(list): Return sum of all values in a list.");
                                            document.write("length(list): Length of a list.");
                                            document.write("mean(list): Mean of a list.");
                                            document.write("median(list): Median of a list. Also in graph_plots.");
                                            document.write("min(list): Minimum value of a list.");
                                            document.write("max(list): Maximum value of a list.");
                                            document.write("quartile(list, quartileNumber): Get quartile quartileNumber of a list.");
                                            document.write("quantile(lst, num): Get quantile number # num of a list lst.");
                                            document.write("stdevp(lst): Standard deviation of a popluation.");
                                            document.write("stdev(lst): Get standard deviation of a list.");
                                            document.write("mad(lst): Get mean absolute deviation of a list.");
                                        } else {
                                            if ((one === "listcalc")) {
                                                document.write("LIST CALCULATOR\n___");
                                                document.write("filterout(1,2,3,4)      Remove strings and negative numbers from list.");
                                                document.write("transform(1,2,3,4)      Remove duplicates from list.");
                                                document.write("reverselt(1,2,3,4)      Reverse a list.");
                                                document.write("mean_calc(1,2,3,4)      Calculate the mean of a list.");
                                                document.write("subt_null(1,2,3,4)      Remove None (null) values from a list.");
                                                document.write("tcsv_conv((1,2),(3,4))  Convert a list to CSV. Raises TypeError if only one row is given.");
                                                document.write("                        Example: tcsv_conv 1,2,3|4,5,6");
                                                document.write("add__list(1,2,3,4)      Add all the numbers on a list.");
                                            } else {
                                                throw new Error("This help page does not exist.");
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

//# sourceMappingURL=main2.js.map
