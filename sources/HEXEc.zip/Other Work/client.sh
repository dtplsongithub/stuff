while true
do
read -t 10 -p "message:" 