# HEXEc Credits:
## Coding:
@dateplays, @NyokoSatouhSato aka Nam, @abruhuser aka __h aka sussy, @Ponali, @globalstorage aka FBI OPEN DOWN [], @mkcodes aka sdf.
## Graphics:
### Icons:
@dateplays, @Ponali
## Other graphics:
@dateplays, @NyokoSatouhSato aka Nam, @abruhuser aka __h aka sussy, @Ponali
## Cursors:
@Ponali (Just found it in a google search)
## Apps:
### @sdf/mkcodes
Calculator,Ace9js (acid IDE),nottrollbox,Wiki,tabbed browser /brz.html,midiplayer
<!--gru-->
### @Ponali
Socket Messenger, Very cute dolphin, Clock, 23841.85791, Google Chrome, File explorer, tabbed browser /brz.html, rate HEXEc
### @abruhuser/__h/sussy
test, Calculator, About, crash the os, Terminal, Socket Messenger.
### @dateplays 
23841.85791, About, Socket Messenger, Terminal

## Ideas:
@dateplays, @Ponali, @androi, @abruhuser/__h/sussy , @XSX360, @sdf <!--sdf>ace9js???-->
## Sounds:
@dateplays, @Ponali
## Boot screen:
@dateplays, @abruhuser, @Ponali
## Desktop:
@abruhuser/__h/sussy, @dateplays
## Welcome message:
@yooperhunter8 for Idea and Text, @dateplays for msgbox() Code
## Server:
@Ponali and @dateplays for ideas 
@Ponali for Coding
## Translation:
@anonymouslol123/memes: Hungarian Edition
@mkcodes/sdf: Hindi Edition
<!--a new line is 2 new lines in markdown
    :0000-->
<!-- write apps u made here evrone -->
## Current versions
We are in beta right now, so we can't get any information about each update.

Version: Beta 3.31

        'logs update'

User-freindly version: 0.3.31 Beta

<!-- WAIT we can codename updates like Windows -->
##### the HEXEc team is made up of 8 peoples.