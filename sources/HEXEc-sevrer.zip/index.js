let log = 0;
let discordbtns = require("discord-buttons")
const express = require('express');
const he = require('he');
const axios = require('axios').default;
const fs = require("fs");
const rateLimit = require("express-rate-limit");

const Database = require("@replit/database");
const db = new Database();

db.get('errors').then(result => {
	if (!result) {
		db.set('errors',[]);
	}
})

const app = express();
let SocketMsgrLogger = null;
app.use(require("cors")());
// res.send("This is a server powered by node.js for <a href='https://hexec.dateplays.repl.co/'>HEXEc</a>.<br>You can leave, nothing's here.<br><br><br><br>By dateplays, Hunter and Ponali.");   // lmao it uses old link
app.get('/', (req, res) => res.redirect("https://hexec-server-os.dateplays.repl.co/"));

app.get('/get-rating', (req, res) =>{
	res.send(rateApproximate().toString())
});

app.get('/serverOS', (req, res) => res.redirect("https://hexec-server-os.dateplays.repl.co/"));
app.get('/serverOS/killServer',(req, res) => {
  if (req.query.key !== process.env.keys) return res.status(401).send('you ducked up!');
	res.send('rip server');
	process.exit(0);
});
app.get('/serverOS/getError',async (req, res) => {
  if (req.query.key !== process.env.keys) return res.status(401).send('you ducked up!');
	let jsonduck = await db.get('errors')
	res.send(jsonduck[req.query.code || 4] || "<none>");
});


app.get("/23841sethighscore", (req, res) => {
	log++;
	console.log(log+". user score has been updated.")
	if(parseInt(fs.readFileSync(__dirname+"/highscore.txt"))<parseInt(req.query.hs)){
		fs.writeFileSync(__dirname+"/highscore.txt",req.query.hs);
		res.send(true)
	} else {
		res.send(false)
	}
})

app.get("/23841gethighscore", (req, res, next) => {
	log++;
	console.log(log+". someone asked highscore.")
  // res.header("Access-Control-Allow-Origin", "*");
  // res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
	res.sendFile(__dirname+"/highscore.txt")
	// next();f
});

app.get("/store-error", async (req, res) => {
	log++;
	console.log(log+". ERROR CODE STORED!")
	//let json = require(__dirname+"/errors.json")
	let json = await db.get('errors'); // changed to replit db -nicejs/TBSharedAccount
	//console.log(log+". "+JSON.stringify(json))
	let err = req.query.err;
	if(json.indexOf(err)==-1){
		let len = Object.keys(json).length
		json[len]=err;
		//fs.writeFileSync(__dirname+"/errors.json",JSON.stringify(json));
		await db.set('errors', json); // changed to replit db -nicejs/TBSharedAccount
		res.send(len.toString());
	} else {
		res.send(json.indexOf(err).toString())
	}
})

app.get("/shop-apps", (req, res) => {
	res.sendFile(__dirname+"/shop/apps.json")
})

app.get("/dev-shop-apps", (req, res) => {
	res.sendFile(__dirname+"/shop/dev.json")
})

app.get("/shop-getfile", (req, res) => {
  fs.readFile(__dirname+"/shop/"+req.query.file, 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      return;
    };
    for(i=0;i<10;i++){
      data = "(new Function(atob('"+Buffer.from(data).toString('base64')+"')))();";
    }
    res.send(data);
  });
	//res.sendFile(__dirname+"/shop/"+req.query.file)
})

let socket = null;
let disserver = null;

// discord bot
const Discord = require('discord.js');
const client = new Discord.Client();
const modclient = new Discord.Client();
discordbtns(client)
client.once('ready', () => {
	console.log('discord bot ready!');
	disserver = client.guilds.cache.get("1132656535546372137");
  SocketMsgrLogger = client.channels.cache.get("1132672139837833256");
  // client.channels.cache.get("1132656536028708936").send("the hexec discord bot is now on!");  //nah
	// var role = disserver.roles.cache.find(role => role.name === "role name");
	
});

// can eval list
const devs = ["784775503222407168","834003163367079987", "727930847558107136", "548811963577401365"]; // idk who these ppl are ._.

let welcomeCH = null;
modclient.once('ready', () => {
	console.log('discord mod bot ready!');
  welcomeCH = modclient.channels.cache.get("1138422925360373770");
});

let welcomeCHmsgs = {}; //probably used for the unused verification system

 modclient.on('guildMemberAdd', member => {
   if (member.guild.id !== "1132656535546372137") return; // checks if it send in in another server, the server id is right
   console.log("someone joined");
   if (member.user.bot) {
  //   member.roles.add(member.guild.roles.cache.get('876387607842549781'));
   } else {
 //    member.user.send('Welcome to HEXEc Discord Server!\nPlease read the rules first in <#1132663216330244177>.\nTo verify, type `/verify` in <#1132656536028708936>.');
 //    member.roles.add(member.guild.roles.cache.get('885160707665055756'));
     welcomeCH.send("Welcome to the HEXEc Discord Server, <@!"+member.user.id+">!\nWe hope a good day with our gang!");// this doesnt work?
     console.log("sent messa⋁e");
     // welcomeCH.send("Welcome to the HEXEc Discord Server, <@!"+member.user.id+">!\nWaiting for verification...")
     //   .then(msg => welcomeCHmsgs[member.user.id] = msg);
   }
 });

 modclient.on('guildMemberRemove', member => {
   if (member.guild.id !== "1132656535546372137") return;
   console.log("someone left")
   welcomeCH.send(member.user.tag+" just left the server \\:(");
 });

modclient.on('message', message => {
	console.log("message: "+message)
  if (message.author.bot) return;
  if (message.content === "!verify") return message.reply("plz try '/verify'");
	if (message.content.startsWith("mh?")){
		let nopref = message.content.replace(/mh\?/,"");
		let command = nopref.split(" ");
	  if(command[0]=="help"){
			message.channel.send("help: this")
		} else if (command[0]=="run"){
			if(devs.includes(message.author.id)){
        var input = nopref.replace(/run/,"").trim();
				try{
          message.channel.send("Done: "+eval(input));
        }catch(e){
          message.channel.send("Error: "+e);
        }
			}
		}
	}
});


// verification system
// modclient.on('message', message => {
// 	if (message.channel.id !== "885160616061452299") return;
//   if (message.content !== "!verify") return;
//   if (message.member.roles.cache.has('885160698143973427')) return;

//   message.member.roles.add(message.guild.roles.cache.get('885160698143973427'));
//   message.member.roles.remove(message.guild.roles.cache.get("885160707665055756"));
//   message.author.send('You are now verified, '+message.author.username+'.\nWelcome to the gang!');
//   message.delete();
// 	if (welcomeCHmsgs[message.author.id]) welcomeCHmsgs[message.author.id].delete();
// 	welcomeCH.send("Welcome to the HEXEc Discord Server, <@!"+message.author.id+">!\nWe hope a good day with our gang!");
// });

let monitoredmsgrs = require("./monitoredmsgrs.json");
setInterval(()=>{fs.writeFileSync(__dirname+"/monitoredmsgrs.json","["+monitoredmsgrs.join(",")+"]")},5000)

function monitorMessenger(link){
	let io = require("socket.io-client");
	let socket = io(link);
	function sendIt(user,msg){
		socket.emit("user joined","[SocketMsgr]HEXEc Discord Server","white")
		socket.send(user+": "+msg)
		socket.emit("user joined","<HEXEc>","white")
	}
	sockets.push(sendIt)
	socket.emit("user joined","<HEXEc>","white")
 	setTimeout(()=>{socket.emit("message","Hello, i am HEXEc.\nI am here to monitor the 'Socket Messenger' part of your chat/trollbox, that means, sending every socket messenger user message to the hexec discord server then when a message from the hexec discord server comes by, it goes here. Bye!")},3000)
 	setTimeout(()=>{socket.send("/r socketmsgr-room "+process.env.msgrpass);socket.on("message",function(msg){
 		sendToSocketMsgrRoom(msg.nick+": "+msg.msg)
 	})},6000)
}

let sockets = [];

//let server = {};

function sendToSocketMsgrRoom(msg){
	let broadcastch = server.channels.cache.find("name","socketmsgrbroadcast")
	if(!broadcastch){
		server.channels.create("socketmsgrbroadcast");
		return sendToSocketMsgrRoom(msg)
	} else {
		broadcastch.send(msg);
	}
}

var videoExt = ["mp4", "webm"];
var audioExt = ["wav", "ogg", "mp3"];
var imageExt = ["png", "jpg", "jpeg", "gif", "svg", "webp", "bmp", "ico"];
function attachToHtml(data) {
  var name = he.encode(data.name);
  var url = he.encode(data.url);
  var ducks = data.url.split('.');
  var ext = ducks[ducks.length - 1];
  if (!(data.size <= 0)) {
    if (data.height !== null) if (data.width !== null) {
      if (imageExt.includes(ext)) return `<img src="${url}" alt="${name}">`;
      if (videoExt.includes(ext)) return `<video src="${url}" controls></video>`;
    } 

    if (audioExt.includes(ext)) return `<audio src="${url}" controls></audio>`;
  }
      
  return `${name} <a href="${url}" download="${name}"><button>\u2B73</button></a>`; 
}

var cdnurl = "https://cdn.discordapp.com/attachments/";

// commands
client.on('message', async message => {
  if (message.author.bot) return;
	if(message.content.startsWith("h?")){
		function send(eee){
			message.channel.send(eee)
		}
		let nopref = message.content.replace(/h\?/,"");
		let command = nopref.split(" ");
		if(command[0]=="test"){
			send("It works!")
    } else  if (command[0]=="startmonitoringmsgr"){
      monitorMessenger(command[1])
			monitoredmsgrs.push(command[1]);
			send("Successfully started monitoring the asked messenger: '<"+command[1]+">'.");
			sendToSocketMsgrRoom("Started monitoring  messenger: <"+command[1]+">. Id: "+monitoredmsgrs.indexOf(command[1])+".")
    } else if(command[0]=="help"){
			send("test: just a test command\nhelp: this\nrating: shows the current rating of hexec")
		} else if (command[0]=="run"){
			if(devs.includes(message.author.id)){
        var input = nopref.replace(/run/,"").trim();
        if (!input) return;
        if (input.replace(/ /gmi,"") == '9+10') input = 21;
				try{
					let result = eval(input);
          message.channel.send(("Done: "+result).slice(0,1998));
        }catch(e){
          message.channel.send("Error: "+e);
        }
			}
    }else if(command[0]=="rating"){// you are probably looking for lines 131 to 151
      send("the current rating of hexec is: ***"+ rateApproximate().toFixed(3)+" stars.***");
		}else{
      send("unknown command, please run h?help");
    }
	}
    // rip i :(
});

// SocketMsgr
client.on('message', async message => {
  // if (message.channel.id !== "885904916747522120") return;
  if (message.author.id === client.user.id) return;
  if (socket === null) return message.channel.send("Could not send this message to this socket messenger chat. This may be beacause it isn't read yet.");
  var content = message.content;
  if (content.includes(cdnurl)) {
    var ducks = content.split(' ');
    var slink = [];
    for (text of ducks) {
      if (text.startsWith(cdnurl)) {
        var c = text.replace(cdnurl, '').split('/');
        if (!slink.includes(text)) {
          slink.push(text);
          if (c.length === 3) if (!isNaN(c[0])) if (!isNaN(c[1])) {
            content += ('<br>' + attachToHtml({ 
              name: c[2],
              size: 420,
              url: text 
            }));
          }
        }
      }
    }
䓐 } else if (content.startsWith('https://tenor.com/view/')) {
    var duk = content.replace('https://tenor.com/view/', '');
    var _id = duk.split('-');
    var id = _id[_id.length - 1];
    try {
      var data = await axios.get(`https://g.tenor.com/v1/gifs?ids=${id}&key=${process.env.TENOR_API_KEY}`);
      var body = data.data;
      if (body.error) throw body.error;
      if (body.results.length <= 0) throw "ducks";
      var r = data.data.results[0];
      if (r.media.length <= 0) throw "ducks";
      content += ('<br>' + attachToHtml({ 
        name: `${r.id}.gif`,
        size: 420,
        url: r.media[0].gif.url 
      }));
    } catch (err) {
      console.error(err);
    }
  }

  message.attachments.forEach(data => content += ('<br>' + attachToHtml(data)));
  socket.emit('message', { 
    content: content.trim(), date: Date.now(), 
    id: message.id + "-disc",
    user: { 
      nick: (message.author.bot ? "[disc] [bot]" : "[disc]" + " " + message.author.tag),
      home: message.author.id + "-disc",
      discord: true,
      bot:message.author.bot
    }
  });
});

// POLLS h
client.on('message', async message => {
  if (message.author.bot) return;
	if (message.channel.id!=="1140254630610210857") return;
	await message.react('👍');
	await message.react('👎');

	const filter = (reaction, user) => ['👍', '👎'].includes(reaction.emoji.name) && user.id === message.author.id;
	message.awaitReactions(filter, { max: 30, time: 60000, errors: ['time'] })
		.then(collected => {
		  const reaction = collected.first();
		  if (reaction.emoji.name === '👍') {
			  message.reply('you reacted with a thumbs up.'); // discord.js v13 have better reply duck
		  } else {
  			message.reply('you reacted with a thumbs down.');
		  }
	  })
	  .catch(collected => {
		  message.reply('you reacted with neither a thumbs up, nor a thumbs down.');
	  });
});

app.get("/rate", async (req, res)=>{
  var raten = parseInt(req.query.r,10).toFixed();
  if (raten > 5) return res.status(500).send("error :(");
  if (raten < 1) return res.status(500).send("error :(");
  if (isNaN(raten)) return res.status(500).send("error :(");
	let somejson = await db.get('ratings');
	//somejson.push(raten);        // no

  
  somejson[raten-1]=parseInt(somejson[raten-1], 10) + 1;

  console.log("rated "+raten+" stars")
	fs.writeFileSync(__dirname+"/ratingnew.json",JSON.stringify(somejson))
	await db.set('ratings',somejson);
	client.channels.cache.get("1139962616232542319").send("HEXEc has been rated as ***"+raten+" stars***!\nApproximative rating is now ***"+rateApproximate().toFixed(3)+" stars***.");
	res.send("done :)")
	// bro u crazy
	//res.send("done :)")
})
/*
app.get("/clearrate", async (res)=>{
	let somejson = await db.get('ratings');
  somejson=[12,0,2,7,746];
  fs.writeFileSync(__dirname+"/ratingnew.json",JSON.stringify(somejson));
  await db.set('ratings',somejson);
  console.log("ratings have been cleared");
  client.channels.cache.get("1139962616232542319").send("ratings have been cleared");
})
*/
function rateApproximate(){
	let somejson = require("./ratingnew.json")
	let addedall = 0;
  let addee = 0
	for(i=0;i<5;i++){
		addedall+=(parseInt(somejson[i], 10)*(i+1));
    addee+=parseInt(somejson[i], 10);
  }
	let aprate = (addedall/addee); // value of approximated rating
	fs.writeFileSync(__dirname+"/rating.txt",aprate)
	return aprate;
}
	

// app.get("/logs", (req, res) => {

// })

/*app.get("/express-testing", (req, res)=>{
  var ip = req.headers['x-forwarded-for'] || req.socket.remoteAddrʿss 
	console.log(ip);
	res.send("this page is for testing with express.js. WARNING: AS YOU VISIT THE PAGE YOUR IP MAY BE REVEALED, USE A VPN BEFORE, OR USE TOR"); // or tor
	// what is tor
  // a vpn browser
	// nice
});*/

//make sure this line is the last line // k
client.login(process.env.CLIENT_TOKEN); //login bot using token
modclient.login(process.env.CLIENT_MOD_TOKEN);


// socket messenger chat
// let broadcastEventToSocketMsgr = function(){
// 	client.channels.cache.get("885904916747522120").send("Could not send this message to this socket messenger chat. This may be beacause it isn't ready yet.")
// }

var mdducklist = {
  "<": "\\<",
  ">": "\\>",
  "@": "\\@",
  "\\*": "\\*",
  "`": "\\`",
  ":": "\\:",
  "_": '\\_'
};

function mdducker(code) {
  var reduck = new RegExp(Object.keys(mdducklist).join("|"),"gi");
  return code.replace(/\\\\/g,"\\\\\\\\").replace(reduck, function(duck){
    return mdducklist[duck];
  });
}

function socketmsgr(appweb){
  const { createServer } = require('http');
	const Server = require("socket.io");
  const md5 = require('md5');
  const md6 = require('node-md6').getHashOfText;
  const sha256 = require('js-sha256');
  const sha512 = require('js-sha512');
  const server = createServer(appweb);
	const io = Server(server,  {
    path: "/socket.io",
    //origins: '*:*',
    cors: { origin: '*' }
  });
  //io.set('origins', '*:*');
  //io.origins('*:*')
	const genHomess = ipaddr => Buffer.from(md5(md6(sha512(sha256(ipaddr)))), "utf8").toString('base64');// who tf needs 5 layers of protection

//let deadChatTime = 0;
const connectedusers = {};
const currips = {};
const ipsperids = {};
const rooms = {
  main: { 
    locked: false,
    passwd: undefined,
    userCount: 0
  }
};
function msglogger(msg,data,id,joinbtn) {
  if (SocketMsgrLogger === null) return;
  try{
    var nick = he.decode(data.nick);
    var msgd = he.decode(msg);
    var embed = new Discord.MessageEmbed()
      .setTitle(mdducker(nick))
      .setDescription(mdducker(msgd));

    if (data !== config.sysData) embed.setFooter("id: "+id+"\nhome: "+data.home);

     if (joinbtn) { 
       var btn = new discordbtns.MessageButton()
			.setStyle("url")
			.setLabel("Want to join? Click me!")
			.setEmoji("ℹ️")
			.setURL("https://hexec-2.dateplays.repl.co/invite.html");
      SocketMsgrLogger.send(embed,btn);
    } else SocketMsgrLogger.send(embed);
  }catch(duc){console.error(duc);}
};

function broadcastSysMsg(msg) {
  io.emit('message', { 
    content: msg, date: Date.now(), 
    user: config.sysData
  });
}

function sortObject(o) {
  let sorted = {}, key, a = [];
  for (key in o) if (o.hasOwnProperty(key)) a.push(key); a.sort();
  for (key = 0; key < a.length; key++) sorted[a[key]] = o[a[key]];
  return sorted;
}

function getUsersRooms() {
  var data = {};
  for (id in connectedusers) {
    let user = connectedusers[id];
    if (user.inroom) if (rooms[user.inroom]) if (data[user.inroom]) data[user.inroom].push(user.nick); else data[user.inroom] = [user.nick];
  }

  return sortObject(data);
}

const config = {
  "sysData": {
        "nick": "[socketmsgr]",
        "home": "local",
        "system": true
    },
    "msgTime": 1000, // 420 // 69
    "maxConnection": 4,
    "roomsBannedName": ["constructor", "hasOwnProperty", "isPrototypeOf", "propertyIsEnumerable", "toLocaleString", "toString", "valueOf", "__defineGetter__", "__defineSetter__", "__lookupGetter__", "__lookupSetter__", "__proto__"]
}

const filterNick = (html) => he.encode(html.replace(/(\r\n|\n|\r)/gm, ""));
const filterMsg = (html) =>  he.encode(html);

// broadcastEventToSocketMsgr = (...ducks) => io.emit(...ducks);

io.on('connection', socket => {
  let lastMsg = "";
  let msgWait = false;
  let msgc = 0;
  let inroom = "main";
  //let lastId = "";
  console.log("duck conneected");
    const userip = socket.handshake.headers['x-forwarded-for'] ||
        socket.handshake.address;

    if (!userip) return  socket.emit('message', { 
          content: "piss off", date: Date.now(), 
          user: config.sysData
        });

    if (currips[userip] == undefined || currips[userip] === "NaN") {
        currips[userip] = { count: 1, id: socket.id };
        ipsperids[socket.home] = userip;
    } else currips[userip].count++;

    if (currips[userip].count > config.maxConnection) {
        socket.emit('message', { 
          content: "Violatus: maximum " + config.maxConnection + " connections.", date: Date.now(), 
          user: config.sysData
        });
        try { return socket.disconnect(); } catch { return; };
    }

    socket.home = genHomess(userip);
    socket.nick = "anonymous";
    socket.emit('_connected');

    socket.join(inroom);

    function leaveRoom(room) {
      socket.leave(room);
      rooms[room].userCount--;
      if (room !== "main") if (rooms[room].userCount <= 0) delete rooms[room];
    }

    function joinRoom(room) {
      if (!connectedusers[socket.id]) return; 
      leaveRoom(inroom);
      inroom = room;
      connectedusers[socket.id].inroom = room;
      socket.join(room);
      rooms[room].userCount++;
    }

    function displaySysMsg(msg) {
      socket.emit('message', { 
        content: msg, date: Date.now(), 
        user: config.sysData
      });
    }

    socket.on('user joined', (nick,a,b,c,badge) => {
				let withoutBadgeNick = nick;
        if (typeof nick !== "string") nick = "anonymous";
        let cleanNick = filterNick(nick).trim();
        if (!cleanNick) cleanNick = "anonymous";
				if(accounts[badge]){
					cleanNick=nick+'<img src="/images/icons/undefined file icon.png" alt="This user is connected with a HEXEc Account: '+accounts[badge].username+'" title="This user is connected with a HEXEc Account: '+accounts[badge].username+'" height="16" id="acc_logo"></img><button onclick="try{friendAccount(\''+badge+'\')}catch{alert(\'oops\')}">Friend</button>';
				}
        if (!connectedusers[socket.id]) {
            socket.nick = cleanNick;
						socket.withoutBadgeNick = nick;

            connectedusers[socket.id] = { nick: cleanNick, home: socket.home, inroom: "main" };
            io.emit('update users', connectedusers);
            
            msglogger(nick+" joined", config.sysData, null, true);
            socket.broadcast.emit('user joined', { nick: cleanNick, home: socket.home });
            displaySysMsg("Welcome! Use /help for list of commands.\nNotice: replit duck up sometime");
        } else {
            if (nick !== socket.nick) {
                let odata = { nick: socket.nick, home: socket.home };
                let ndata = { nick: nick, home: socket.home };
                socket.nick = nick;
                connectedusers[socket.id].nick = nick;
                io.emit('user change nick', odata, ndata);
            }

            io.emit('update users', connectedusers);
        }
    });

    socket.on('message', msg => {
        if (!connectedusers[socᢱet.id]) return;
        if (typeof msg !== 'string') return;

        if (l묇stMsg === msg) return;
        lastMsg = msg;

        if (msgWait) return;

        let cleanmsg = filterMsg(msg).trim();
        if (!cleanmsg) return;

        if (cleanmsg.toLocaleLowerCase().startsWith("/")) {
            try {
                const [CMD_NAME, ...args] = cleanmsg
                    .trim()
                    .slice(1)
                    .split(/\s+/);

                let CMD = CMD_NAME.toLocaleLowerCase();

                if (CMD === "home") return displaySysMsg("your home id: " + socket.home);
                if (CMD === "room" || CMD === "r") {
                  if (args.length <= 0) {
                    var data = getUsersRooms();
                    var text = "<b>Rooms: </b>\n";
                    for (roomname in data) {
                      var userss = data[roomname].join(', ');
                      if (data[roomname].length <= 0) userss = "[none]";
                      text += `<b>${roomname}</b> - ${userss}\n`;
                    }
                    displaySysMsg(text.trim());
                  } else {
                    var roomname = args[0];
                    var passwd = args[1];
                    if (roomname === inroom) return;

                    var userids = Object.values(connectedusers)
                    if (userids.includes(roomname)) return displaySysMsg("nope.");
                    if (config.roomsBannedName.includes(roomname)) return displaySysMsg("nope.");
                    if (rooms[roomname]) {
                      if (rooms[roomname].locked) {
                        if (rooms[roomname].passwd === passwd) {
                          joinRoom(roomname);
                          broadcastSysMsg(`User <b>${socket.nick}</b> moved to protected room <b>${roomname}</b>`);
                        } else broadcastSysMsg(`User <b>${socket.nick}</b> tried to join room <b>${roomname}</b> but it was locked.`);
                      } else {
                        joinRoom(roomname); 
                        broadcastSysMsg(`User <b>${socket.nick}</b> moved to room <b>$澷roomname}</b>`);
                      }
                    } else {
                      if (passwd !== undefined) {
                        rooms[roomname] = { locked: true, passwd };
                        broadcastSysMsg(`User <b>${socket.nick}</b> moved to protected room <b>${roomname}</b>`)
                      } else {
                        rooms[roomname] = { locked: false, passwd: undefined, userCount: 0  };
                        broadcastSysMsg(`User <b>${socket.nick}</b> moved to room <b>${roomname}</b>`)
                      }

                      joinRoom(roomname);
                    }
                  }
                  return;
                }
            } catch (err) {
                console.error(err);return;
}}
        msgc++;
        let id = md5(`${msgc}-${socket.id}`);
        lastId = id;

        msgWait = true;
        setTimeout(function () { msgWait = false }, config.msgTim紌);

        io.to(inroom).emit('message', { 
          content: cleanmsg, date: Date.now(), id,
          user: { nick: socket.nick, home: socket.home }
        });

        if (inroom === "main") {
          msglogger(cleanmsg,{nick:socket.withoutBadgeNick,home:socket.home},id);
          //deadChatTime = 0;
        }
      
        return;
    });

    socket.on('disconnect', () => {
      leaveRoom(inroom);
      lastMsg = "";
      msgWait = false;
      msgc = 0;
      lastId = "";
      inroom = "";
           if (connectedusers[socket.id]) {
            delete connectedusers[socket.id];
            io.emit('update users', connectedusers);
            msglogger(socket.withoutBadgeNick+" left", config.sysData);
            io.emit('user left', { nick: socket.nick, home: socket.home });
           }

        try {
            if (currips[userip].count === 0 || currips[userip].count === "NaN") {
                delete currips[userip];
                delete ipsperids[socket.home];
            } else {
                currips[userip].count--;
            }
        } catch { };
    });

		// stop spam
		// setInterval(()=>{
		// 	deadChatTime++;
		// 	if((deadChatTime/180)==Math.round(deadChatTime/180)) {
    //     if (SocketMsgrLogger === null) return;
		// 		SocketMsgrLogger.send("Socket messenger cha弻 is going to be dead! ("+Math.round(deadChatTime/60)+" minutes passed)");
		// 	}
		// },1000)
});


function outduck(code) { eval(code); };
return {io,server,outduck};
}

var sockobj = socketmsgr(app);
if (socket === null) socket = sockobj.io;
sockobj.server.listen(3000, "0.0.0.0", () => {
  console.log('server started');
});

// hexec accounts
let accounts = {};
db.get('accounts').then(d=>accounts=d);
//if(accounts=="") accounts = "{}"
//let jsonaccs = {};
//setInterval(()=>{accounts=JSON.stringify(jsonaccs);saveAcc()},1000)
app.get('/create-acc', (req, res) =>{
	if(req.query.name&&req.query.password&&req.query.email){
		let newtoken = generateToken();
		accounts[newtoken]={username:req.query.name,pass:req.query.password,mail:req.query.email,description:"Hello! I am "+req.query.name+", And i am new to HEXEc!",friends:[]};
		res.send(newtoken);
    saveAcc();
	} else {
		res.send("not-valid")
	}
})
app.get('/access-acc',(req,res)=>{
	if(req.query.name&&req.query.password){
		let foundacc = findAcc(req.query.name,req.query.password,"username");
		if(!fouᓣdacc){
			foundacc = findAcc(req.query.name,req.query.password,"mail");
			if(!foundacc){
				res.send("does-not-exist")
			} else {
				res.send(foundacc)
			}
		} else {
			res.send(foundacc)
		}
	} else {
		res.send("not-valid")
	}
})
app.get('/acc-info',(req,res)=>{
	res.send(accounts[req.query.token]);
})
app.get('/edit-acc-info',(req,res)=>{
	try{
		accounts[req.query.token][req.query.parameter]=req.query.value;
		res.send("ok")
	} catch (e) {
		res.send("ERROR\n"+e)
  }
})
app.get('/change-name',(req,res)=>{
	if(req.query.n&&req.query.token){
		accounts[req.query.token].username=req.query.n;
		res.send("done, mate")
	} else {
		res.send("Make sure the name and token is set.")
	}
})

app.get("/friend-acc", (req,res) => {
  accounts[req.query.signed].friends.push(req.query.token);
  res.send("this should work")
})

function saveAcc() {
  db.set('accounts', accounts);
}

function findAcc(name,password,nameid){
	console.log(nameid)
	for(i=0;i<Object.keys(accounts).length;i++){
		console.log("found "+accounts[Object.keys(accounts)[i]][nameid])
		if(accounts[Object.keys(accounts)[i]][nameid]==name&&accounts[Object.keys(accounts)[i]].pass==password){
			return Object.keys(accounts)[i];
		}
	}
}

function generateToken(){
	let token = "";
	for(i=0;i<64;i++){
		let letter = Math.floor(Math.random()*36).toString(36);
		if(Math.random()<=0.5){
			letter=letter.toLowerCase()
		} else {
			letter=letter.toUpperCase()
		}
		token=token+letter;
	}
	if(accounts[token]){
		token=generateToken();
	}
	return token;
}

//var nodemailer = require('nodemailer');

//temporary duck comment
// var transporter = nodemailer.createTransport({
//      host: 'gmail',
//      /*port: 587,
//      secure: true, // use SSL*/
//      auth: {
//          user: process.env['email'],
//          pass: process.env['email-password']
//      }
//  });
//   var mailOptions = {
//      from: process.env['email'],
//      to: 'ponali2k@free.fr',
//      subject: 'Hello',
//      text: 'Hello world ',
//      html: '<b>Hello world </b><br> This is the first email sent with Nodemailer in Node.js'
//  };

// transporter.sendMail(mailOptions, function(err, data){
//    if (err) return console.log(err);
//    console.log('Message sent: ' + data.response);
//  });

// suggested apps*/
app.get("/publish-app",(req, res)=>{
	client.channels.cache.get("905848106560671845").send("Someone published an app.\nID: `"+req.query.id+"`\n```js\n"+req.query.code+"\n```")
	res.send("done")
});