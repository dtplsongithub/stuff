apps.aclidenix = {
  "name" :"Aclidenix",
  "icon" : "exe file icon",
  "exec" :aclidenixapp
}

function aclidenixapp() {
  win({
    title:"Aclidenix",
    inner:"<iframe width=800px height=600px src=https://aclidenix-udn.udnsystems.repl.co />",
    width: 830,
    height: 630,
    maximizable: false,
    minimizable: true,
    closable: true
  })
}