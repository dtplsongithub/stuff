for(i=0;i<localStorage.length;i++){
	if(localStorage.key(i).split("/").length==2){
		/*apps[localStorage.key(i)]={
			"name": localStorage.key(i),
			"exec": app(localStorage.key(i)),
			"icon": "text file icon.png"
		};*/
		let name = localStorage.key(i);
		apps[name]={"name": name.slice(1,name.length),"exec":function(){app(name)},"icon": "text file icon.png"};
	}
}