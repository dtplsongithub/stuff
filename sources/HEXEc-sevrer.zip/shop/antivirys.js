apps.antivirys = {
	"name":"Antivirys v1",
	"icon":"antivirys.png",
	"exec": a
}

function a() {
  //console.log('ducked');
  popup("images/icons/antivirys.png","Dangerous file found.","File name/path: <br><b>/plugins/antivirys</b><br><button>Quarantine</button><button>Delete</button><button>Open Virus list</button>");
  msgbox("Install Antivirys?","info","Antivirys v1",[{
    title:"Yes",
    script: yes1
  },
  {
    title:"No",
    script: function(id) { win.instances[id].close(); }
  }
  ],"info")
}

function yes1(id0) {
  if (typeof id0 === 'number') win.instances[id0].close();
  var id = win({
    title: "Installing...",
    inner: "",
    closable: false,
    minimizable: true,
    maximizable: false,
    width: 300,
    height: 100
  });

  win.instances[id].inner.innerHTML = "<center>Installing...</center><br><progress id='proc_"+id+"'></progress>";
}