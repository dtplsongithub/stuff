apps.appmake = {
	"name": "HEXEc App Maker",
	"icon": "../../favicon.ico",
	"exec": appmake
}

function appmake(){
	let id = win({inner:"Plugin Id:<input type='text'></input><br><textarea width='600' height='400' style='font-family: monospace;'></textarea><br><button>Save</button><button>Publish</button>(Before Publishing, make sure there's your discord account name and tag (Example#6969) written in the code.)",title:"HEXEc App Maker Beta",closable:true,minimizable:true,maximizable:true,width:600,height:600})
	let winin = win.instances[id];
	winin.inner.querySelectorAll("button")[0].addEventListener("click",function(){
		try{ eval(winin.inner.querySelector("textarea").value); showdesktop() } catch (e) {
			alert(e)
		}
		localStorage["/plugins/"+winin.inner.querySelector("input").value]=winin.inner.querySelector("textarea").value;
	},false)
	winin.inner.querySelectorAll("button")[1].addEventListener("click",function(){
		fetch("https://hexec-sevrer.dateplays.repl.co/publish-app?code="+decodeURIComponent(winin.inner.querySelector("textarea").value)+"&id="+winin.inner.querySelector("input").value)
	},false)
}