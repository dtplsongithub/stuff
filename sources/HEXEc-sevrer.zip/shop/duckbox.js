apps.duckbox = {
	"name":"DuckBox",
	"icon":"duck.png",
	"exec": duckbox
}

function duckbox(){
	win({ title: "DuckBox Chat", inner: '<iframe src="https://invduck.abruhuser.repl.co/duckbox/index.html" frameborder="0" style="width:100%;height:100%;" width="100%"></iframe>', closable: true, maximizable: true, minimizable: true, resizable: true, width: 600, height: 400 });
}