function testResults (form) {
   console.log(form.dif.value)
}