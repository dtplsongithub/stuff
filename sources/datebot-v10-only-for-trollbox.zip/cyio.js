let io = require("socket.io-client");
const socket = io("https://cyio.trollbox.party/", { forceNew: true, path: '/api/v0/si' });
socket.emit("user joined", "datebot (d.) [no commands yet]", "#ee9911", "", "")
// Ponali, please, repaire the code.
socket.send("test","message")
 setTimeout(()=>{
 	socket.send("hfhfhfhfh","message")
 },1000);