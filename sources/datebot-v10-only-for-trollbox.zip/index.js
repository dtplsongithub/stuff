const io = require("socket.io-client");
var fetch = require("node-fetch");
//require("./cyio");
const socket = io("https://sussite.tk/", { forceNew: true });
function rename() {
  socket.emit("user joined", "datebot (d.)", "yellow", "bot", "")
}; rename()
//the bot means that its bot
//so bot badge adds
//it does not works like this
//const socket = io("https://cyio.trollbox.fun/");
const gateway = io("https://rmtbgateway.globalstorage.repl.co", { forceNew: true });
//trollbox fun is ducked up, its requires to type befor sending msg
const he = require("he")
let bot = { prefix: "d." }
let sentmsg = "lol";
let version = "1.1.1.2021824.115"
function sendMsg(msg) {
  if (msg == sentmsg) {
    msg += "\u200b";
  }
  sentmsg = msg;
  socket.emit("message", msg);
}
sendMsg("╭─────────────────────────────Welcome────────────────────────────╮\n│ this datebot was under development or the admin was not here to│\n│ start me. now i am here!                                       │\n│ Type d.help if you want to use me                              │\n│ Version: " + version + "                                     │\n│                                                                │\n│                                                                │\n│ datebot version " + version + "                              │\n╰────────────────────────────────────────────────────────────────╯");
function sendEmbed(title, imageon, image, footer) {
  if (imageon == true) {
    socket.send(`<section class="skin_inset _mr5">${title}<br><img src="${image}" style="max-height:700px;max-width:500px;height:auto;width:auto;"><br>${footer}</section>`);
  } else {
    sendMsg(`<section class="skin_inset _mr5">${title}<br>${footer}</section>`);
  }
};
bot.commands = {}
// bot.commands[bot.prefix+"test"]={description:"Test the bot!",hidden:false,exec:function(){sendMsg("if you see this it's working yay");}}


bot.commands[bot.prefix + "help"] = { description: "command library", hidden: false, exec: function() { let result = []; for (i = 0; i < Object.keys(bot.commands).length; i++) { result.push(Object.keys(bot.commands)[i] + " ".repeat(20 - Object.keys(bot.commands)[i].length) + "  --  " + bot.commands[Object.keys(bot.commands)[i]].description) }; sendMsg("Hello, i am datebot v1.0 and my commands are:\n" + result.join("\n")); } }


bot.commands["HEXEc"] = { description: "", hidden: true, exec: function() { sendMsg("//hexec-2.dateplays.repl.co"); } }
bot.commands[bot.prefix + "h"] = { description: "just h", hidden: false, exec: function() { sendMsg("https://www.youtube.com/watch?v=DwjbP7aihxQ\nhttps://www.youtube.com/watch?v=UAiH9XCWEk4"); } }
// bot.commands[bot.prefix+"f"]={description:"respect paid",hidden:false,exec:function(){sendMsg("respect paid B)");}}
bot.commands["f"] = { description: "respect paid", hidden: false, exec: function() { sendMsg("respect paid B)"); } }
bot.commands["t"] = { description: "That's just not respectful.", hidden: false, exec: function() { sendMsg("That's just not respectful.>:("); } }
bot.commands[bot.prefix + "alphabet"] = { description: "the alphabet", hidden: false, exec: function() { sendMsg("abcdefghijklmnopqrstuvwxyz\nthe alphabet is ez"); } }
bot.commands[bot.prefix + "resetname"] = { description: "a command that resets the datebot's name", hidden: false, exec: function(data) { socket.emit("user joined", "datebot (d.)", "yellow", "bot", "") } }
bot.commands[bot.prefix + "changename"] = { description: "a command that changes the bot's name", hidden: false, exec: function(data) { socket.emit("user joined", data.msg.replace(bot.prefix + "changename ", "") + " (d.)", "yellow", "bot", "") } }
bot.commands[bot.prefix + "say"] = { description: "i guess this command will appear in any bot :|", hidden: false, exec: function(data) { socket.send(data.msg.replace(bot.prefix + "say ", "")) } };
// now i will put here a lot of my text file from my pc named datebot data.txt
bot.commands[bot.prefix + "yes"] = { description: "yes", hidden: false, exec: function() { sendMsg("yes"); } }
bot.commands[bot.prefix + "no"] = { description: "yes but no", hidden: false, exec: function() { sendMsg("no"); } }
bot.commands[bot.prefix + "maybe"] = { description: "probably", hidden: false, exec: function() { sendMsg("maybe"); } }
bot.commands[bot.prefix + "games"] = { description: "if ur bored", hidden: false, exec: function() { sendMsg("https://bonk.io/\nhttps://agar.io/#ffa\nhttps://diep.io/\nhttp://slither.io/"); } }
bot.commands[bot.prefix + "other_trollboxes"] = { description: "<b><i>trollbox</i></b>", hidden: false, exec: function() { sendMsg("original windows 93 [dead :( ]:\nhttp://www.windows93.net/trollbox/\ntrollbox.fun:\nhttps://trollbox.party/\nCYIO chatbox:\nhttps://cyio.trollbox.party/\nWindows 96 trollbox:\nhttps://devel.windows96.net:4096/\ntrollbox++:\nhttps://box.km.mk/\nrmtrollbox(this one):\nhttp://rmtrollbox.eu-gb.mybluemix.net/\ndateplays's trollbox (or frepl trollbox):\nhttps://frepltrollbox.dateplays.repl.co/\ntrollbox v0:\nhttps://tb.dacousb.com/\nduckbox chat:\nhttps://invduck.abruhuser.repl.co/duckbox/"); } }


bot.commands[bot.prefix + "about"] = { description: "About", hidden: false, exec: function() { sendMsg("This is datebot version " + version + " powered by node.js\nCredits to Ponali and globalstorage(aka FBI OPEN DOWN []) for helping me"); } }


bot.commands[bot.prefix + "whatsnew"] = { description: "What's new?", hidden: false, exec: function() { sendMsg("1.0.202165.85 (juny 5 version 85 lines of code):\nadded what's new, no and maybe\n\n1.0.202165.105 (juny 5 version 105 lines of code):\nadded d.<i>duck</i>\n\n1.0.202165.106 (juny 5 version 106 lines of code):\nadded d.officialsite\n\n1.0.202166.107 (juny 6 version 111 lines of code):\nadded that message when started datebot\n1.0.202166.111 (juny 6 version 111 lines of code):\nadded that message when started datebot\n 1.1.20210819 (august 19 version 113 lines of code):\ndatebot is finnaly back!"); } }
bot.commands[bot.prefix + "officialsite"] = { description: "the official admin's site", hidden: false, exec: function() { sendMsg("https://dateplayss-main-page.dateplays.repl.co/"); } }
/*bot.commands[bot.prefix+"duck"]={description:"ducks",hidden:false,exec:function(){
  fetch("https://random-d.uk/api/random").then(function(resp){
      resp.text().then(function(data){
        sendEmbed("Quack!", true, JSON.parse(data).url.replace("https:",""), "Powered by random-d.uk.");
      });
  });
}}*/
//Pls wait, copying duck command code from my bot... // oh ok
//globalstorage type here
//H eis gRaeT
socket.on("message", function(data) {
  data.nick = he.decode(data.nick);
  data.msg = he.decode(data.msg);
  console.log(data.nick, data.msg);
  let cmd = { index: data.msg.split(" ")[0] }
  if (bot.commands[cmd.index]) {
    bot.commands[cmd.index].exec(data);
  } else {
    if (data.msg.startsWith(bot.prefix)) {
      sendMsg("This command is nonexisty (yet...)\nPlease use d.help to visit command library.")
    }
  }
  /* if (data.msg == bot.prefix+"test"){
    sendMsg("if you see this it's working yay");
  }
  if (data.msg == bot.prefix+"oof"){
    sendMsg("roblox oof");
  } no why?*/
  //i am doing another way, ok?
  // so just wait
  // don't do anything
  // ok
})

// rmtrollbox gateway
var ignore_disconnect = false;
gateway.on("up", function(flag) {
  if (!flag) {
    ignore_disconnect = true;
    socket.disconnect();
  } else {
    ignore_disconnect = false;
    if (socket.disconnected) {
      rename()
    }
  }
});
socket.on("disconnect", function() {
  if (!ignore_disconnect) {
    socket.connect();
    rename();
  }
})
gateway.on("disconnect", function(d) { socket.connect(); sendMsg("Gateway sent a disconnect event. Reason: " + d); });

var d = require("express")();
d.get("/", (_, r) => r.send("datebot/v1.0"));
d.listen(5115);