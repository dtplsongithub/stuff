# HEXEc Credits:
## Coding:
@dtpls, @NyokoSatouhSato aka Nam, @abruhuser aka sussy, @Ponali, @globalstorage aka FBI OPEN DOWN [], @mkcodes aka sdf, @nicejsisverycool (or ShyGuyMask)
## Graphics:
### Icons:
@dtpls, @Ponali, @sdf/mkcodes (i guess)
## Other graphics:
@dtpls, @NyokoSatouhSato aka Nam, @abruhuser aka sussy, @Ponali
## Cursors:
@Ponali
## Apps:
### @sdf/mkcodes
(sdfemu,Calculator+,Ace9js,3chat,My files,firefox-test (unreleased))
NOTE: pheditor is not by me but by pheditor/pheditor
### @Ponali
(Socket Messenger, Very cute dolphin, Clock, 23841.85791, Google Chrome, File explorer) and 95% of the hexec server code
### @abruhuser/sussy
(test, Calculator, About, crash the os, Terminal, Socket Messenger).
### @dtpls
(23841.85791, About, Socket Messenger, Terminal)
### @nicejsisverycool
HXS

## Ideas:
@dateplays, @Ponali, @androi, @abruhuser/sussy , @XSX360/Blocky
## Sounds:
@dateplays, @Ponali
## Boot screen:
@dateplays, @abruhuser, @Ponali
## Desktop:
@abruhuser/sussy

<!--a new line is 2 new lines in markdown
    :0000-->
<!-- write apps u made here evrone -->
## Current versions
We are in beta right now, so we can't get any information about each update.

Version: 0.11

        'revival'

User-freindly version: 0.11 Beta

<!-- WAIT we can codename updates like Windows -->
##### the HEXEc team is made up of 9 peoples. 