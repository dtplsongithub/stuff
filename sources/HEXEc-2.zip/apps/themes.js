apps.themes = {

  exec: themeds,
  hide:true
}

function themeds () {
  win({
    title:"themes",
    inner:"the theme app is broken and i uhhhhhhhhhhhh",
    closable:true,
    minimizable: true,
    maximizable: false,
    width:700,
    height:450
  });
}