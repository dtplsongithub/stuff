// recreation of youareanidiot.org or youdontknowwhoiam.org
// please do it yourself
// idea by ponali

//
//
//               you are an idiot
//
//             :)       :)       :)
//
//