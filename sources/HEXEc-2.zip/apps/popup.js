apps.popup_test = {
  "name":"popup test",
  "exec": popuptest,
  hide:true,
  "icon":"exe file icon.png"
}

function popuptest () {
  popup("msgbox%20icons/info.png","test!","test");
  popup("msgbox%20icons/error.png","popup works","yey");
  popup("images/icons/undefined%20file%20icon.png","unknown file found","unknown file found. <br> name: e.dom <br>this file might be dangerous. please remove it right now. <button>remove</button>");
}
// it doesnt work? 
// reload
// also i said hi on chat
// i am on phone
// oh :(
// cant join om pc for another 3-4 hours
// ah. D:
// no its ok its 7:37 am at me
// its 6:37 am at me :PPPPPPPP
// did u see that
// yes
// select a word then do control shift l (sorry youre on mobile)
// great why you ruined the code
// i put it back buddy ;)
// ah repl.it server bugs ok
// yeah there is a lot of buggssssss
// but the popup still doesnt work... 
// im going to add some stuff to css
// k
// default theme will get edits