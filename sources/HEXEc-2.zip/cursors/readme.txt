﻿=== Smooth Classic Cursor Set ===

By: Vlasta (http://www.rw-designer.com/user/1)

Download: http://www.rw-designer.com/cursor-set/antialiased-classic

Author's decription:

Classic Windows cursors with built-in shadows and antialiased edges. This set contains all classic cursors and three alternative ones (pendulum arrow, lightbulb, and animated unavailable sign).

If you are using this set on Vista Beta 2, be sure to disable cursor shadow in control panel. The cursors already contain shadows.

==========

License: Creative Commons - Attribution

You are free:

* To Share - To copy, distribute and transmit the work.
* To Remix - To adapt the work.

Under the following conditions:

* Attribution - You must attribute the work in the manner specified
  by the author or licensor (but not in any way that suggests that
  they endorse you or your use of the work). For example, if you are
  making the work available on the Internet, you must link to the
  original source.