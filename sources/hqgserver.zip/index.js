let M=Math;
let fs = require('fs');
const { createServer } = require("http");
const { platform } = require('os');
const { Server } = require("socket.io");
let rules = "";
fs.readFile(__dirname+"/rules.txt","utf8",(err,data)=>{
  if(err) throw err;
  rules = data;
})

const httpServer = createServer();
const io = new Server(httpServer, {
  cors:{
    origin:"*" // sites you want to allow requests from, like the hqg client. temporarily set to * to allow all.
  }
});

let playerList = [];
let platformData = [];

function addPlatform(){
  let type=0; // normal
  if(M.random()>0.97){
    type=1; // platform kills you
  }
  if(M.random()>0.95){
    type=2; // powerup platform
  }
  if(M.random()>0.96){
    type=3; // uncollidable platform
  }
  if(M.random()>0.92){
    type=4; // bouncey platform
  }
  let movable=(M.random()>0.95)
  let cond=(M.random()/10+platformData.length/200)<0.5;
  if(cond){
    type=0; // don't allow special platforms until a certain point is reached
    movable=false;
  }
  if(platformData.length!=0&&platformData[platformData.length-1].type!=0){type=0;}
  platformData.push({"x":M.random()*500-300,"width":M.random()*200+50,"height":30,"type":type,"extraData":[movable,(M.random()>0.5)*2-1,M.random()*4+1]});
}

function startGame(){
  platformData=[];
  for(let i=0;i<10;i++){
    addPlatform();
  }
  io.emit("platformData",platformData);
}

io.on("connection", (socket) => {
  socket.on("joinCredentials",(cred)=>{
    console.log(socket.id+" joined with name "+cred.name)
    socket.emit("confirmRules",rules)
    socket.on("rulesAccepted",()=>{
      console.log(cred.name+" accepted the rules and joined");
      socket.emit("setState",0);
      playerList.push({"id":socket.id,"credentials":cred});
      io.emit("playerList",playerList);
      socket.on("message",(msg)=>{
        if(msg.message.replaceAll(" ","").length==0){
          return;
        }
        console.log("got message from "+msg.user+": "+msg.message);
        io.emit("message",msg);
      })
      socket.on("disconnect",()=>{
        console.log(cred.name+" left the game");
        playerList = playerList.filter(player=>player.id!=socket.id);
        io.emit("playerList",playerList);
      });
      socket.on("requestGameStart",()=>{
        console.log(cred.name+" requested to start the game");
        io.emit("setState",1);
        startGame();
      });
      socket.on("gamePlayerMove",(data)=>{
        io.emit("gamePlayerMove",data);
      });
      socket.on("requestPlatforms",()=>{
        for(let i=0;i<10;i++){addPlatform();}
        io.emit("platformData",platformData);
      });
      socket.on("eliminatePlayer",(pid)=>{
        io.emit("eliminatePlayer",pid);
      })
      socket.on("legPassed",(currentLeg)=>{
        io.emit("legPassed",currentLeg,socket.id);
      })
      socket.on("playerFreeze",(data)=>{
        io.emit("playerFreeze",data);
      })
      socket.on("playerUnfreeze",(data)=>{
        io.emit("playerUnfreeze",data);
      })
      socket.on("freezeBulletUpdate",(data)=>{
        io.emit("freezeBulletUpdate",data);
      })
      socket.on("freezeBulletUpdate",(data)=>{
        io.emit("freezeBulletUpdate",data);
      })
    })
  })
});

httpServer.listen(3000); // if you want to edit the port to something else than this, you can, and ill make it the default port to use in the client
// ok