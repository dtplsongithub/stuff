var img = new Image();
var img2 = new Image();
img.onload = (()=>{
  img2.onload = (()=>{
    setInterval(update, 1000 / FPS);
  })
  img2.src = "/=).png";
})
img.src = "/tetst.png";
var c = document.getElementById("canvas");
var ctx = c.getContext('2d');
const FPS = 60;
var t = 0;
c.width = innerWidth;
c.height = 600;
var cx, cy;
cx = c.width / 2;
cy = c.height / 2;
function update() {
  ctx.fillStyle = "#77f";
  ctx.fillRect(0, 0, c.width, c.height);
  t++
  ctx.drawImage(img, t%5*32, 0, 32, 32, 30, 30, 32, 32);
  ctx.beginPath();
  ctx.setLineDash([t%10+1, 10-t%10+1]);
  ctx.moveTo(0, 80);
  ctx.lineTo(1000, 50);
  ctx.stroke();
  ctx.drawImage(img2, Math.floor(t/30)%5*500, 0, 500, 100, cx-500/2, cy-100/2, 500, 100);
  ctx.strokeStyle = "black";
  ctx.setLineDash([])
  ctx.beginPath();
  ctx.roundRect(400, 150, -200, 100, [50, 0, 50, 0]);
  ctx.stroke();
}