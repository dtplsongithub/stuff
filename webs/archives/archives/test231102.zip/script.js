var f = "";
function oninputtt() {
  f = document.getElementById("f").value.split("\n");
  let K = Math.floor(Math.random()*(f.length))
  document.getElementById("h").innerText = `${K+1}.  ${f[K]}`;
  f.splice(K, 1);
  f = f.join("\n");
  document.getElementById("f").value=f
}