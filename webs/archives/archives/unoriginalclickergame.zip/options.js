function testResults (form) {
  localStorage["/themes/chosen"] = form.theme.value;
  window.location.href="https://unoriginalclickergame.dateplays.repl.co/";
}